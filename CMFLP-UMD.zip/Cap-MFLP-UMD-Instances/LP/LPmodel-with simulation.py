"""
LP code for CMFLP-UMD
Author : Amirreza Pashapour - 2023
"""
# Libraries
import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
from pyomo.environ import *

# %% Connecting to Excel
address = r'C:\Users\Amirreza\Desktop\Amirreza\POMS\Cap-MFLP-UMD\Example-20.xlsx'
Network_data = pd.read_excel(address, sheet_name='Network')
Arc_data = pd.read_excel(address, sheet_name='Arcs')
R_data = pd.read_excel(address, sheet_name='Initial R')
M_data = pd.read_excel(address, sheet_name='Initial M')
C_data = pd.read_excel(address, sheet_name='Cij')
Network_data = pd.DataFrame(Network_data)
Arc_data = pd.DataFrame(Arc_data)
R_data = pd.DataFrame(R_data)
M_data = pd.DataFrame(M_data)
C_data = pd.DataFrame(C_data)
C_dimension = (C_data.shape)
C_len = range(C_dimension[0])

c = {}        # Generating Cij matrix
for i in C_len:
    for j in C_len:
        c[(i,j)] = (C_data.loc[i][j])

R_dimension = (R_data.shape)
nR = R_dimension[0]
R = list(range(1, nR+1))

tau = int(R_data.loc[0]['Tau'])

M_dimension = (M_data.shape)
nM = M_dimension[0]
M = list(range(1, nM+1))

b = {}
o = {}
for m in M:
    b[m] = M_data['cap'][m-1]
    o[m] = M_data['o'][m-1]
#ser = nM * cap

Nodes = [int(a) for a in list(Network_data['Nodes'])]

Ir = list(Network_data['Ir'])
for i in range(len(Ir)-1, 0, -1):
    if pd.isnull(Ir[i]) == True:
        Ir.pop()
    else:
        break
Ir = [int(a) for a in Ir]

Im = list(Network_data['Im'])
for i in range(len(Im)-1, 0, -1):
    if pd.isnull(Im[i]) == True:
        Im.pop()
    else:
        break
Im = [int(a) for a in Im]

Camp = list(Network_data['Camp'])
for i in range(len(Camp)-1, 0, -1):
    if pd.isnull(Camp[i]) == True:
        Camp.pop()
    else:
        break
Camp = [int(a) for a in Camp]

Arc_list = []
for k in range(len(Arc_data)):
    a1 = Arc_data['i'][k]
    a2 = Arc_data['j'][k]
    Arc_list.append((a1, a2))

pij = {}
for i in range(len(Ir)):
    pij[Ir[i]] = (Network_data['Pij'][i])
now_LR_r = {}
now_F_r = {}
d = {}
for r in R:
    now_LR_r[r] = list(R_data['Location'])[r-1]
    now_F_r[r] = list(R_data['G'])[r-1]
    d[r] = list(R_data['pop'])[r-1]
now_LM_m = {}
for m in M:
    now_LM_m[m] = list(M_data['Location'])[m-1]

#d = list(R_data['pop'])   # population size of each RG
now_LR = []        # where the refugees are right now
now_F = []
now_LM = []
for r in R:
    now_LR.append(tuple([r, now_LR_r[r]]))
    now_F.append(tuple([r, now_F_r[r]]))
for m in M:
    now_LM.append(tuple([m, now_LM_m[m]]))
now = []
now.append((tuple(now_LR), tuple(now_F), tuple(now_LM)))
now = now[0]

#%%
def combination(arr):  # This function is used several times to choose a combination from sets
    y = []
    # number of arrays
    n = len(arr)
    # to keep track of next element in each of the n arrays
    indices = [0 for i in range(n)]

    while (1):
        # prcurrent combination
        a = []
        for i in range(n):
            a.append(arr[i][indices[i]])
        y.append(a)

        # find the rightmost array that has more elements left
        # after the current element in that array
        next = n - 1
        while (next >= 0 and
               (indices[next] + 1 >= len(arr[next]))):
            next -= 1

        # no such array is found so no more combinations left
        if (next < 0):
            return y

        # if found move to next element in that array
        indices[next] += 1

        # for all arrays to the right of this array current index
        # again points to first element
        for i in range(next + 1, n):
            indices[i] = 0

def GRR(r_nodes,r_edges):
    graph = {}
    for n in r_nodes:
        adj = []
        for e in r_edges:
            if n == e[0]:
                adj.append(e[1])
            if n == e[1]:
                adj.append(e[0])
        graph[n] = adj
    return graph
Rgraph = GRR(Ir , Arc_list)  # Adjacent nodes

SP = {}  # Shortest path from each node to its nearest camp node
def shortest_path(Rgraph, node1, destination):
    path_list = [[node1]]
    path_index = 0
    # To keep track of previously visited nodes
    previous_nodes = {node1}
    if node1 in destination:
        return path_list[0]
        
    while path_index < len(path_list):
        current_path = path_list[path_index]
        last_node = current_path[-1]
        next_nodes = Rgraph[last_node]
        # Search goal node
        for i in destination:
            if i in next_nodes:
                current_path.append(i)
                return current_path
        # Add new paths
        for next_node in next_nodes:
            if not next_node in previous_nodes:
                new_path = current_path[:]
                new_path.append(next_node)
                path_list.append(new_path)
                # To avoid backtracking
                previous_nodes.add(next_node)
        # Continue to next path in list
        path_index += 1
    # No path is found
    return []       
    
for i in Ir:
    SP[i] = shortest_path(Rgraph, i, Camp)    
   
# %% Pij matrix generation
P = {}   # Pij matrix

for i in Ir:
    if i in Camp:
        for j in Ir:
            if i == j:
                P[(i,j)] = 1
            else:
                P[(i,j)] = 0
    else:
        non_link = len(Rgraph[i])
        for j in Ir:
            if j == SP[i][1]:  # i-j is a SP link
                P[(i,j)] = pij[i]
            elif j == i or (i,j) in Arc_list or (j,i) in Arc_list:
                P[(i,j)] = (1 - pij[i]) / non_link
            else:
                P[(i,j)] = 0

# %% LR & LM generation
H = [Ir] * nR

All_r_loc = combination(H)
LR = []
for i in All_r_loc:
    row = []
    for r in R:
        row.append((r, i[r-1]))
    LR.append(tuple(row))

# F generation
tau_length = []
for r in R:
    tau_length.append(list(range(1, tau+1)))
G = []
All_g = combination(tau_length)
for i in All_g:
    row = []
    for r in R:
        row.append((r, i[r-1]))
    G.append(tuple(row))

H2 = [Im] * nM

All_m_loc = combination(H2)
LM = []
for i in All_m_loc:
    row = []
    for m in M:
        row.append((m, i[m-1]))
    LM.append(tuple(row))

# %% State space

State = []

for lr in LR:
    for g in G:
        for lm in LM:
            State.append((lr, g, lm))

# %% Action generation
Action = []   # General list for actions

def A_gen(a_state): 
    dest_a = []
    r_loc = []
    service_loc = []
    for r in R:
        r_loc.append(a_state[0][r-1][1])
    for value in r_loc:
        if value in Im and value not in service_loc:
            service_loc.append(value)
    for m in M:
        dest_a_m = []
        for y in [0,1]:
            if y == 0: # No action
                dest_a_m.append([m,y,a_state[2][m-1][1]])
            else:
                for idx in service_loc:
                    dest_a_m.append([m,y,idx])
        dest_a.append(dest_a_m)
    temp_a = combination(dest_a)
    good_a = []
    
    for act in temp_a:
        capacity = {}
        boolean = {}
        demand = {}
        for idx in service_loc:
            capacity[idx] = 0
            boolean[idx] = 0
            for m in M:
                if act[m-1][1]==1 and act[m-1][2]==idx:
                    capacity[idx] += b[m]
                    boolean[idx] = 1
                    
            demand[idx] = 0
            for r in R:
                if a_state[0][r-1][1] == idx:
                    demand[idx] += d[r]
        add = True
        for idx in service_loc:
            if capacity[idx] < demand[idx] * boolean[idx]:
                add = False
        if add == True:
            good_a.append(act)

    return good_a

# %% Cost function

def Cost_Function(a_state, a_action):
    relocationCost = 0
    serviceActCost = 0
    penaltyCost = 0
    
    #service
    for m in M:
        if a_action[m-1][1] == 1:
            serviceActCost += o[m]
    
    #relocation
    target = []
    for m in M:
        if a_action[m-1][1] == 1:
            relocationCost += c[(a_state[2][m-1][1],a_action[m-1][2])]
            target.append(a_action[m-1][2]) # service nodes for sure
    
    #penalty
    for r in R:
        if a_state[1][r-1][1] == 1 and a_state[0][r-1][1] not in target: # not served
            penaltyCost += lamda
                
    return relocationCost + serviceActCost + penaltyCost

# %% Next States

def Next_State(a_state, a_action):
    Next_S = []  # List of potential next observable states
    P_S = {}  # List for probability of observing each Next_V
    # Part 1 - LR
    Adj_list = []
    for r in R:
        r_adj = [a_state[0][r-1][1]]  # append r's current location
        for j in Rgraph[a_state[0][r-1][1]]:
            r_adj.append(j)
        Adj_list.append(r_adj)
    comb_adj_list = combination(Adj_list)
    Next_LR = []
    for i in range(len(comb_adj_list)):
        Next_LR_ind = []
        for r in R:
            Next_LR_ind.append((r, comb_adj_list[i][r-1]))
        Next_LR.append(Next_LR_ind)

    # Part 2 - F
    F_list = []
    target_r = []
    dest = list(set([a_action[m-1][2] for m in M if a_action[m-1][1] == 1]))
    for r in R:
        if a_state[0][r-1][1] in dest:
            target_r.append(r)
            
    for r in R:
        if r in target_r or a_state[0][r-1][1] in Camp:
            F_list.append((r, tau))
        else:
            k = max(1,a_state[1][r-1][1]-1)  # Checking deprivation
            F_list.append((r, k))

    # Part 3 - LM
    M_list = []
    for m in M:
        M_list.append((m, a_action[m-1][2]))


    # Combining the information to create next_V s:
    for i in range(len(Next_LR)):
        new_state = (tuple(Next_LR[i]), tuple(F_list), tuple(M_list))
        Next_S.append(new_state)

    # Probabilities
    for s in Next_S:
        prob = 1
        for r in R:
            prob = prob * P[(a_state[0][r-1][1] , s[0][r-1][1])]
        P_S[s] = prob

    return Next_S, P_S

# %% Optimization

def Optimization(a_state, VF, VFA):
    # step 1: generate all feasible actions
    action_list = A_gen(a_state)
    ActionCosts = [0]*len(action_list)   # create cost list for each action
    
    index = 0
    for a in action_list:
        # immediate cost
        ActionCosts[index] += Cost_Function(a_state, a)
        NextStates, Probabilities = Next_State(a_state, a)
        for s in NextStates:
            ActionCosts[index] += B * Probabilities[s] * \
                VF[s]
        index += 1
    VF[a_state] = min(ActionCosts)
    VFA[a_state] = action_list[np.argmin(ActionCosts)]

def Next_Post_State(a_state, a_action, wtg):
    
    Next_S = []  # List of potential next observable states
    Next_LR = wtg
    # Part 2 - F
    F_list = []
    target_r = []
    dest = list(set([a_action[m-1][2] for m in M if a_action[m-1][1] == 1]))
    for r in R:
        if a_state[0][r-1][1] in dest:
            target_r.append(r)
            
    for r in R:
        if r in target_r or Next_LR[r-1][1] in Camp:
            F_list.append((r, tau))
        else:
            k = max(1,a_state[1][r-1][1]-1)  # Checking deprivation
            F_list.append((r, k))

    # Part 3 - LM
    M_list = []
    for m in M:
        M_list.append((m, a_action[m-1][2]))


    # Combining the information to create next_V s:
    Next_S = (tuple(Next_LR), tuple(F_list), tuple(M_list))

    return Next_S

def Roulette_Wheel(Prob):
    C = np.cumsum(Prob)
    rnd = random.random()
    for i in range(len(Prob)):
        if C[i] >= rnd:
            break
    return i    # returning a index

def Simulation(old_state, a_action):
    where_now = old_state[0]
    where_to_go = []
    for r in R:
        where_r = where_now[r-1][1]
        where_r_to_go = []
        p_r_to_go = []
        for j in Ir:
            if P[(where_r , j)]>0:
                where_r_to_go.append(j)
                p_r_to_go.append(P[(where_r , j)])
        destination = where_r_to_go[Roulette_Wheel(p_r_to_go)]
        where_to_go.append((r,destination))
    F_LM = Next_Post_State(old_state, a_action, where_to_go)
    simul = (tuple(where_to_go), F_LM[1], F_LM[2])
    
    return simul


SS = []

for i in range(100):
    a_state = now
    while Go:
        a_state = Simulation(a_state,)
        Go = False
        for i in a_state[0]:
            if i[1] not in Camp:
                Go = True
                break


#%% LP model
B = 0.98   # discount factor
lamda = 100

model = ConcreteModel()

model.V = Var(State, within = NonNegativeReals)

model.OF = Objective(expr = sum(model.V[s] for s in State)
                     ,sense = maximize)

model.limit = ConstraintList()

for s in State:
    X = A_gen(s)
    for x in X:
        NextStates, Probabilities = Next_State(s, x)
        
        model.limit.add(model.V[s] <= Cost_Function(s, x) + B * sum(Probabilities[ns] * model.V[ns] for ns in NextStates))
#%%
solver = SolverFactory('cplex').solve(model, tee=True, timelimit=300)

#%% Results
'''
print('Initial state:', now)
print('Value f:', VF[now])
print('Optimal action:', VFA[now])
print('Run time:', final - start)

print('States with service acts:')
for s in range(len(State)):
    if VFA[s][0][1]!=0:
        print(State[s], '-', VFA[s])
plot = plt.figure(1)
plt.plot(range(len(V_now)), V_now)
plt.xlabel('Iteration')
plt.ylabel('Value f of initial state')

plot = plt.figure(2)
plt.plot(range(len(V_ave)),V_ave)
plt.xlabel('Iteration')
plt.ylabel('Average Value f') '''
