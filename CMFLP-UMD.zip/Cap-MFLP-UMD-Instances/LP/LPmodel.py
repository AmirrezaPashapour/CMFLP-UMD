"""
LP code for CMFLP-UMD
Author : Amirreza Pashapour - 2024
"""
# Libraries
import pandas as pd
import matplotlib.pyplot as plt
from pyomo.environ import *

#%%
def combination(arr):  # This function is used several times to choose a combination from sets
    y = []
    # number of arrays
    n = len(arr)
    # to keep track of next element in each of the n arrays
    indices = [0 for i in range(n)]

    while (1):
        # prcurrent combination
        a = []
        for i in range(n):
            a.append(arr[i][indices[i]])
        y.append(a)
        # find the rightmost array that has more elements left
        # after the current element in that array
        next = n - 1
        while (next >= 0 and
               (indices[next] + 1 >= len(arr[next]))):
            next -= 1
        # no such array is found so no more combinations left
        if (next < 0):
            return y
        # if found move to next element in that array
        indices[next] += 1
        # for all arrays to the right of this array current index
        # again points to first element
        for i in range(next + 1, n):
            indices[i] = 0

# %% Pij matrix generation

def Sigma(welfare):
    if welfare == 1:
        return 0.6
    elif welfare == 2:
        return 0.7
    else:
        return 0.8

def P_calc(p_state,p_state_dest):
    finalP = 1
    for r in R:
        i = p_state[0][r-1][1]       # l^r_t
        if i in Camp:
            continue
        else:
            j = p_state_dest[0][r-1][1]  # l^r_t+1
            u2 = p_state_dest[1][r-1][1] # welfare level of RG r in t+1
            denom = Zeta[r] * Kappa[i,SP[i][1]] + (1-Zeta[r]) * sum(Kappa[i,k] for k in Rgraph[i] if k != SP[i][1])
    
            if j == SP[i][1]:  # Case 1
                finalP *= ((Zeta[r] * Kappa[i,j])/denom) * Sigma(u2)
            elif j in Rgraph[i]: # Case 2
                finalP *= (((1-Zeta[r]) * Kappa[i,j])/denom) * Sigma(u2)
            elif j == i:
                finalP *= 1 - Sigma(u2)
            else:
                finalP *= 0
    return finalP

# %% Action generation

def A_gen(a_state): 
    dest_a = []
    service_loc = list(set([v for v in [a_state[0][r-1][1] for r in R] if v in Im]))
    for m in M:
        dest_a_m = []
        for y in [0,1]:
            if y == 0: # No action
                dest_a_m.append([m,y,a_state[2][m-1][1]])
            else:
                for idx in service_loc:
                    dest_a_m.append([m,y,idx])
        dest_a.append(dest_a_m)
    good_a = []
    
    for act in combination(dest_a):
        capacity = {}
        boolean = {}
        demand = {}
        for idx in service_loc:
            capacity[idx] = 0
            boolean[idx] = 0
            for m in M:
                if act[m-1][1]==1 and act[m-1][2]==idx:
                    capacity[idx] += b[m]
                    boolean[idx] = 1
                    
            demand[idx] = 0
            for r in R:
                if a_state[0][r-1][1] == idx:
                    demand[idx] += d[r]
        add = True
        for idx in service_loc:
            if capacity[idx] < demand[idx] * boolean[idx]:
                add = False
                break
        if add == True:
            good_a.append(act)

    return good_a

# %% Cost function

def Cost_Function(a_state, a_action):
    #service
    serviceActCost = sum(o[m] for m in M if a_action[m-1][1] == 1)
    #relocation
    relocationCost = sum(c[(a_state[2][m-1][1],a_action[m-1][2])] for m in M if a_action[m-1][1] == 1)
    #penalty
    penaltyCost = sum(gamma for r in R if a_state[1][r-1][1] == 1 and a_state[0][r-1][1] not in [a_action[m-1][2] for m in M if a_action[m-1][1] == 1])
         
    return relocationCost + serviceActCost + penaltyCost

# %% Next States

def Next_State(a_state, a_action):
    # Part 1 - LR
    Adj_list = []
    for r in R:
        r_adj = [a_state[0][r-1][1]]  # append r's current location
        if a_state[0][r-1][1] not in Camp:
            for j in Rgraph[a_state[0][r-1][1]]:
                r_adj.append(j)
        Adj_list.append(r_adj)
    comb_adj_list = combination(Adj_list)
    Next_LR = []
    for i in range(len(comb_adj_list)):
        Next_LR_ind = []
        for r in R:
            Next_LR_ind.append((r, comb_adj_list[i][r-1]))
        Next_LR.append(Next_LR_ind)

    # Part 2 - U
    ULR = []
    target_r = [r for r in R if a_state[0][r-1][1] in list(set([a_action[m-1][2] for m in M if a_action[m-1][1] == 1]))]
    for nlr in Next_LR:
        U_list = []
        for r in R:
            if r in target_r or nlr[r-1][1] in Camp:
                U_list.append((r, tau))
            else:
                U_list.append((r, max(1,a_state[1][r-1][1]-1)))
        ULR.append((tuple(nlr), tuple(U_list)))
    # Part 3 - LM
    M_list = [(m, a_action[m-1][2]) for m in M]
    
    Next_S = [(ULR[i][0], ULR[i][1], tuple(M_list)) for i in range(len(Next_LR))]
    P_S = {s:P_calc(a_state, s) for s in Next_S}

    return Next_S, P_S

#%% LP model
Instance_List = ['\\I01-R2M1.xlsx']
for instance_id in Instance_List:
    
    # % Connecting to Excel
    address1 = r'C:\Users\apashapour20\Desktop\POMS\Cap-MFLP-UMD-Instances\Datasets\Network.xlsx'
    address2 = r'C:\Users\apashapour20\Desktop\POMS\Cap-MFLP-UMD-Instances\Datasets' + instance_id

    Network_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Network'))
    Arc_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Arcs'))
    R_data = pd.DataFrame(pd.read_excel(address2, sheet_name='Initial R'))
    M_data = pd.DataFrame(pd.read_excel(address2, sheet_name='Initial M'))
    C_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Cij'))
    Om     = pd.DataFrame(pd.read_excel(address1, sheet_name='Om'))
    SP_data = pd.DataFrame(pd.read_excel(address1, sheet_name='SP'))
    Scalars = pd.DataFrame(pd.read_excel(address1, sheet_name='Scalars'))
    c = {(i,j):(C_data.loc[i][j]) for i in range((C_data.shape)[0]) for j in range((C_data.shape)[0])}
    R    = list(range(1, R_data.shape[0] + 1))
    M    = list(range(1, M_data.shape[0] + 1))
    tau  = int(Scalars.loc[0]['Tau'])
    gamma  = int(Scalars.loc[0]['Gamma'])
    b    = {m:M_data['cap'][m-1] for m in M}
    ocap = {Om['Caps'][i]: Om['o'][i] for i in range(len(Om))}
    o    = {}
    for m in M:
        for i in ocap:
            if b[m] == i:
                o[m] = ocap[i]
    Nodes = [int(a) for a in list(Network_data['Nodes'])]

    Ir = list(Network_data['Ir'])
    for i in range(len(Ir)-1, 0, -1):
        if pd.isnull(Ir[i]) == True:
            Ir.pop()
        else:
            break
    Ir = [int(a) for a in Ir]

    Im = list(Network_data['Im'])
    for i in range(len(Im)-1, 0, -1):
        if pd.isnull(Im[i]) == True:
            Im.pop()
        else:
            break
    Im = [int(a) for a in Im]

    Camp = list(Network_data['Camp'])
    for i in range(len(Camp)-1, 0, -1):
        if pd.isnull(Camp[i]) == True:
            Camp.pop()
        else:
            break
    Camp = [int(a) for a in Camp]

    Arc_list = [(Arc_data['i'][k], Arc_data['j'][k]) for k in range(len(Arc_data))]
    Kappa    = {(Arc_data['i'][k], Arc_data['j'][k]):Arc_data['Kappa'][k] for k in range(len(Arc_data))}
    Zeta     = {r: R_data['Zeta'][r-1] for r in R}
    d        = {r: list(R_data['pop'])[r-1] for r in R}   
    now_LR_r = {r: list(R_data['Location'])[r-1] for r in R}
    now_U_r  = {r: list(R_data['U'])[r-1] for r in R}
    now_LM_m = {m: list(M_data['Location'])[m-1] for m in M}
    now_LR   = [tuple([r, now_LR_r[r]]) for r in R]
    now_F    = [tuple([r, now_U_r[r]]) for r in R]
    now_LM   = [tuple([m, now_LM_m[m]]) for m in M]
    now      = (tuple(now_LR), tuple(now_F), tuple(now_LM))
    
    # Adjacent nodes
    Rgraph = {n:[e[1] for e in Arc_list if n == e[0]] for n in Ir}

    SP = {}
    for i in range(len(SP_data)):
        row = list(SP_data.loc[i][j] for j in SP_data)
        for j in range(len(row)-1, 0, -1):
            if pd.isnull(row[j]) == True:
                row.pop()
            else:
                break
        SP[int(SP_data.loc[i][1])] = [int(a) for a in row]
    
    # % LR & LM generation
    LR = [tuple([(r, i[r-1]) for r in R]) for i in combination([Ir] * R_data.shape[0])]
    U  = [tuple([(r, i[r-1]) for r in R]) for i in combination([list(range(1, tau+1)) for r in R])]
    LM = [tuple([(m, i[m-1]) for m in M]) for i in combination([Im] * M_data.shape[0])]
    Removal = []
    State = [(lr, u, lm) for lr in LR for u in U for lm in LM]
    for s in State:
        for r in R:
            if s[0][r-1][1] in Camp and s[1][r-1][1] != tau:
                Removal.append(s)
    State = list(set(State) - set(Removal))
    
    # Parameters
    B     = 0.98   # discount factor
    model = ConcreteModel()
    model.V = Var(State, within = NonNegativeReals)
    #model.OF = Objective(expr = sum(model.V[s] for s in State) ,sense = maximize)
    model.OF = Objective(expr = sum((1/len(State)) * model.V[s] for s in State) ,sense = maximize)
    
    model.limit = ConstraintList()
    
    for s in State:
        X = A_gen(s)
        for x in X:
            NextStates, Probabilities = Next_State(s, x)
            
            model.limit.add(model.V[s] <= Cost_Function(s, x) + B * sum(Probabilities[ns] * model.V[ns] for ns in NextStates))
    
    #%%
    solver = SolverFactory('gurobi').solve(model, tee=True)
    print("V*[now] =", value(model.V[now]))
    
#%%
'''
def Optimize(ss,coef):
    return min([Cost_Function(ss, a) + B * Basis(Next_Post_State(ss, a), coef) for a in A_gen(ss)])

V1 = []
V2 = []
for i in range(50):
    s = State_gen()
    V1.append(value(model.V[s]))
    V2.append(Optimize(s,Theta))

plot = plt.figure(2)
plt.plot(range(len(V1)),V1, label = 'LP')
plt.plot(range(len(V1)),V2, label = 'ADP')
plt.xlabel('Iteration')
plt.ylabel('Value function')
plt.title('Value function of the initial state')
plt.legend()'''
#%%
'''
V1 = []
V2 = []
for s in State:
    V1.append(value(model.V[s]))
    V2.append(Optimize(s,Theta))
VV1 = sum(V1)
VV2 = sum(V2)

#%%
print(VV1/len(State))
print(VV2/len(State))

#%%
V1 = []
V2 = []
SSS = [(((1, 1), (2, 2)), ((1, 2), (2, 3)), ((1, 0),)),
       (((1, 1), (2, 5)), ((1, 2), (2, 3)), ((1, 0),)),
       (((1, 3), (2, 5)), ((1, 2), (2, 3)), ((1, 0),)),
       (((1, 7), (2, 8)), ((1, 3), (2, 3)), ((1, 0),)),
       (((1, 7), (2, 8)), ((1, 2), (2, 2)), ((1, 0),)),
       (((1, 7), (2, 8)), ((1, 1), (2, 1)), ((1, 0),))]
for s in SSS:
    V1.append(value(model.V[s]))
    V2.append(Optimize(s,Theta))

plot = plt.figure(3)
plt.plot(range(len(V1)),V1, label = 'LP')
plt.plot(range(len(V1)),V2, label = 'ADP')
plt.xlabel('Iteration')
plt.ylabel('Value function')
plt.title('Value function of the initial state')
plt.legend()
'''
