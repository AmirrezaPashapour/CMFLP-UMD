"""
Variable Threshold Policy (VTP) code for CMFLP-UMD
Author : Amirreza Pashapour - 2024
"""
# Libraries
import pandas as pd
import math
import random
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
from pyomo.environ import *

#%%
def combination(arr):  # This function is used several times to choose a combination from sets
    y = []
    # number of arrays
    n = len(arr)
    # to keep track of next element in each of the n arrays
    indices = [0 for i in range(n)]
    while (1):
        # prcurrent combination
        a = []
        for i in range(n):
            a.append(arr[i][indices[i]])
        y.append(a)
        # find the rightmost array that has more elements left
        # after the current element in that array
        next = n - 1
        while (next >= 0 and
               (indices[next] + 1 >= len(arr[next]))):
            next -= 1
        # no such array is found so no more combinations left
        if (next < 0):
            return y
        # if found move to next element in that array
        indices[next] += 1
        # for all arrays to the right of this array current index
        # again points to first element
        for i in range(next + 1, n):
            indices[i] = 0

# %% Pij matrix generation
def P_calc(p_state,p_state_dest):
    finalP = 1
    for r in R:
        i = p_state[0][r-1][1]       # l^r_t
        if i in Camp:
            continue
        else:                # en route  # computing scores
            u2 = 0
            if p_state_dest[1][r-1][1] == tau:
                u2 = 1
            
            score = {}
            for j in Rgraph[i]:
                score[(i,j)] = W_vector['w1'] * NDist[(i,j)] + W_vector['w2'] * Popularity[j] + W_vector['w3'] * SPIndex[(i,j)] 
                
            score[(i,i)] = W_vector['w4'] * (tau - p_state[1][r-1][1]) + W_vector['w5'] * (1 - u2) + W_vector['w6'] * (1-Velocity[r]) 
            #print(score)
            finalP *= (score[i,p_state_dest[0][r-1][1]])/(sum(score.values()))

    return finalP

#%%
def Roulette_Wheel(Prob):
    C = np.cumsum(Prob)
    rnd = random.random()
    for i in range(len(Prob)):
        if C[i] >= rnd:
            break
    return i    # returning a index

def Next_State(a_state, a_action):
    # Part 1 - LR
    Adj_list = []
    for r in R:
        r_adj = [a_state[0][r-1][1]]  # append r's current location
        if a_state[0][r-1][1] not in Camp:
            for j in Rgraph[a_state[0][r-1][1]]:
                r_adj.append(j)
        Adj_list.append(r_adj)
    comb_adj_list = combination(Adj_list)
    Next_LR = []
    for i in range(len(comb_adj_list)):
        Next_LR_ind = []
        for r in R:
            Next_LR_ind.append((r, comb_adj_list[i][r-1]))
        Next_LR.append(Next_LR_ind)

    # Part 2 - U
    ULR = []
    target_r = [r for r in R if a_state[0][r-1][1] in list(set([a_action[m-1][2] for m in M if a_action[m-1][1] == 1]))]
    for nlr in Next_LR:
        U_list = []
        for r in R:
            if r in target_r or nlr[r-1][1] in Camp:
                U_list.append((r, tau))
            else:
                U_list.append((r, max(1,a_state[1][r-1][1]-1)))
        ULR.append((tuple(nlr), tuple(U_list)))
    # Part 3 - LM
    M_list = [(m, a_action[m-1][2]) for m in M]
    
    Next_S = [(ULR[i][0], ULR[i][1], tuple(M_list)) for i in range(len(Next_LR))]
    P_S = {s:P_calc(a_state, s) for s in Next_S}

    return Next_S[Roulette_Wheel(list(P_S.values()))]

# %%  Which RGs are candidate to be served?
def ServiceAct(S):
    Rhat = [r for r in R if S[0][r-1][1] not in Camp]
    if len(Rhat) == 0:
        return False, [], 'NA'
    T = RangeSet(tau)
    while True:
        
        model = ConcreteModel()
        model.e = Var(T, within = Binary)
        model.f = Var(T, M, Rhat, within = Binary)
        model.OF = Objective(expr = sum(model.e[t] for t in T))
        model.limit = ConstraintList()
        for r in Rhat:
            model.limit.add(sum(b[m] * model.f[t,m,r] for m in M for t in T) >= d[r])
        for m in M:
            for t in T:
                model.limit.add(sum(model.f[t,m,r] for r in Rhat) <= model.e[t])
        for j in RangeSet(tau-1):
            model.limit.add(model.e[j] >= model.e[j+1])
        solver = SolverFactory('gurobi').solve(model)
        
        eta = value(model.OF)
        w = False
        
        Rremove = [r for r in Rhat if S[1][r-1][1] > eta]
        if len(Rremove) > 0:
            Rhat = list(set(Rhat) - set(Rremove))
            w = True
        if len(Rhat) == 0:
            doSA = False
            RG = []
            break
        else:
            if w == True:
                continue
            else:
                doSA = True # Serve
                RG = Rhat
                break
    return doSA, RG, eta

solver = SolverFactory('gurobi')
Instance_List = ['\\I01-R2M2.xlsx', '\\I02-R2M3.xlsx', '\\I03-R3M3.xlsx', '\\I04-R3M4.xlsx', '\\I05-R4M3.xlsx',
                 '\\I06-R4M4.xlsx', '\\I07-R5M5.xlsx', '\\I08-R5M6.xlsx', '\\I09-R6M7.xlsx', '\\I10-R6M8.xlsx',
                 '\\I11-R6M9.xlsx', '\\I12-R7M9.xlsx', '\\I13-R7M10.xlsx', '\\I14-R7M11.xlsx', '\\I15-R8M11.xlsx',
                 '\\I16-R8M12.xlsx', '\\I17-R8M13.xlsx', '\\I18-R9M13.xlsx', '\\I19-R9M14.xlsx', '\\I20-R9M15.xlsx']

#Instance_List = ['\\I02-R2M3.xlsx']

#Instance_List = ['\\I01-R2M2.xlsx', '\\I02-R2M3.xlsx', '\\I03-R3M3.xlsx', '\\I04-R3M4.xlsx', '\\I05-R4M3.xlsx',
#                 '\\I06-R4M4.xlsx', '\\I07-R5M5.xlsx', '\\I08-R5M6.xlsx', '\\I09-R6M7.xlsx', '\\I10-R6M8.xlsx']
Instance_List = ['\\I12-R7M9.xlsx']

AvgCost = [] 
StdCost = []
Times   = []
Viols   = []
for instance_id in Instance_List:
    
    # % Connecting to Excel
    address1 = r'C:\Users\apashapour20\Desktop\New POMS\Cap-MFLP-UMD-Instances\Datasets\Network.xlsx'
    address2 = r'C:\Users\apashapour20\Desktop\New POMS\Cap-MFLP-UMD-Instances\Datasets' + instance_id

    Network_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Network'))
    Arc_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Arcs'))
    R_data = pd.DataFrame(pd.read_excel(address2, sheet_name='Initial R'))
    M_data = pd.DataFrame(pd.read_excel(address2, sheet_name='Initial M'))
    C_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Cij'))
    Dist_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Dist'))
    SP_data = pd.DataFrame(pd.read_excel(address1, sheet_name='SP'))
    Scalars = pd.DataFrame(pd.read_excel(address1, sheet_name='Scalars'))
    W_data = pd.DataFrame(pd.read_excel(address1, sheet_name='W_vector'))
    Dists = {(i,j):Dist_data.loc[i][j] for i in range((Dist_data.shape)[0]) for j in range((Dist_data.shape)[0])}
    c = {(i,j):(C_data.loc[i][j]) for i in range((C_data.shape)[0]) for j in range((C_data.shape)[0])}
    R    = list(range(1, R_data.shape[0] + 1))
    M    = list(range(1, M_data.shape[0] + 1))
    tau  = int(Scalars.loc[0]['Tau'])
    gamma  = int(Scalars.loc[0]['Gamma'])
    b    = {m:M_data['cap'][m-1] for m in M}
    o    = Scalars['o'][0]
    Nodes = [int(a) for a in list(Network_data['Nodes'])]

    Ir = list(Network_data['Ir'])
    for i in range(len(Ir)-1, 0, -1):
        if pd.isnull(Ir[i]) == True:
            Ir.pop()
        else:
            break
    Ir = [int(a) for a in Ir]

    Im = list(Network_data['Im'])
    for i in range(len(Im)-1, 0, -1):
        if pd.isnull(Im[i]) == True:
            Im.pop()
        else:
            break
    Im = [int(a) for a in Im]

    Camp = list(Network_data['Camp'])
    for i in range(len(Camp)-1, 0, -1):
        if pd.isnull(Camp[i]) == True:
            Camp.pop()
        else:
            break
    Camp = [int(a) for a in Camp]

    Arc_list = [(Arc_data['i'][k], Arc_data['j'][k]) for k in range(len(Arc_data))]
    # Adjacent nodes
    Rgraph = {n:[e[1] for e in Arc_list if n == e[0]] for n in Ir}

    NDist = {}
    for i in Ir:
        denom = sum(1/Dists[i,j] for j in Rgraph[i])
        for j in Rgraph[i]:
            NDist[i,j] = round((1/Dists[i,j]) / denom , 3)
    Popularity = {i: int(Network_data['Popularity'][Ir.index(i)]) for i in Ir}
    W_vector = {W_data['w'][k]: W_data['value'][k] for k in range(len(W_data))}
    SPIndex  = {(Arc_data['i'][k], Arc_data['j'][k]): Arc_data['SPIndex'][k] for k in range(len(Arc_data))}
    d        = {r: list(R_data['pop'])[r-1] for r in R}
    now_LR_r = {r: list(R_data['Location'])[r-1] for r in R}
    Velocity = {r: list(R_data['Velocity'])[r-1] for r in R}
    now_U_r  = {r: list(R_data['U'])[r-1] for r in R}
    now_LM_m = {m: list(M_data['Location'])[m-1] for m in M}
    now_LR   = [tuple([r, now_LR_r[r]]) for r in R]
    now_F    = [tuple([r, now_U_r[r]]) for r in R]
    now_LM   = [tuple([m, now_LM_m[m]]) for m in M]
    now      = (tuple(now_LR), tuple(now_F), tuple(now_LM))
    # Adjacent nodes
    Rgraph = {n:[e[1] for e in Arc_list if n == e[0]] for n in Ir}

    SP = {}
    for i in range(len(SP_data)):
        row = list(SP_data.loc[i][j] for j in SP_data)
        for j in range(len(row)-1, 0, -1):
            if pd.isnull(row[j]) == True:
                row.pop()
            else:
                break
        SP[int(SP_data.loc[i][1])] = [int(a) for a in row]
    #%% Main Loop
    B = 0.98   # discount factor
    N = 100
    Go = True
    period = []             # Length of simulation paths
    #%%
    vviol = 0
    TCost = []
    start = datetime.now()
    print(instance_id, '| started at:', start)
    for n in range(N):
        #if (n+1) % 10 == 0:
        #    print(n/10)
        
        Go = True
        per = 0
        pre_state = now
        Cost = []
        power = 0
        while (1):
            # Stop simulations if all RGs have reached camps
            Action = []
            
            doSA, RG, ETA = ServiceAct(pre_state)
    
            #print(doSA, LRG)
            if doSA == True: # if some SA must be done
                LRG = list(set([pre_state[0][r-1][1] for r in RG if pre_state[0][r-1][1] not in Camp]))
                f_under = {i: min(pre_state[1][r-1][1] for r in R if pre_state[0][r-1][1] == i) for i in LRG}
                Xi = {j:[l for l in LRG if f_under[l]==j] for j in RangeSet(ETA)}
                    
                # generate GAP
                Model = ConcreteModel()
                Model.x = Var(M,LRG, within = Binary)
                Model.y = Var(LRG, within = Binary)
                
                Model.obj = Objective(expr = sum(o * d[r] * Model.y[i] for i in LRG for r in RG if pre_state[0][r-1][1] == i) + sum(c[(pre_state[2][m-1][1],i)] * Model.x[m,i] for m in M for i in LRG)
                                      - sum(gamma * d[r] * Model.y[i] for i in LRG for r in RG if pre_state[0][r-1][1] == i))
                
                Model.limit1 = ConstraintList()
                for m in M:
                    Model.limit1.add(sum(Model.x[m,i] for i in LRG) <= 1)
                
                Model.limit2 = ConstraintList()
                for i in LRG:
                    Model.limit2.add(sum(b[m] * Model.x[m,i] for m in M) >= Model.y[i] * sum(d[r] for r in RG if pre_state[0][r-1][1]==i))        
                
                Model.limit3 = ConstraintList()
                for j in RangeSet(ETA - 1):
                    for k in RangeSet(j+1,ETA):
                        for i in Xi[j]:
                            for ii in Xi[k]:
                                Model.limit3.add(Model.y[i]>=Model.y[ii])
                    
                solver.solve(Model)
               
                for m in M:
                    if value(sum(Model.x[m,i] for i in LRG)) < 0.5:
                        Action.append([m,0,pre_state[2][m-1][1]])
                    else:
                        for i in LRG:
                            if value(Model.x[m,i] > 0.5):
                                Action.append([m,1,i])
                                break
    
                Cost.append(B**power * value(sum(o * d[r] * Model.y[i] for i in LRG for r in RG if pre_state[0][r-1][1] == i) + sum(c[(pre_state[2][m-1][1],i)] * Model.x[m,i] for m in M for i in LRG)))
    
            else:
                Cost.append(0)
                for m in M:
                    Action.append([m,0,pre_state[2][m-1][1]])
            
            old_f = list(pre_state[1][r-1][1] for r in R)
            
            # Simulation phase
            old_s = pre_state
            pre_state = Next_State(pre_state, Action)
            new_f = list(pre_state[1][r-1][1] for r in R)
            
            for r in R:
                if old_f[r-1] == 1 and new_f[r-1] == 1:
                    Cost[-1] += B**power * gamma * d[r]
                    vviol += 1
            #print(old_s, ' - Act:', Action, ' - Cost:', round(Cost[-1],2), 'viol:',vviol)
            power+=1
            Go = False
            for i in pre_state[0]:
                if i[1] not in Camp:
                    Go = True
                    per += 1  #sample path not completed. We continue 1 more epoch.
                    break
            if Go == False:
                TCost.append(sum(Cost))
                break
        period.append(per)
    final = datetime.now()
    ave_obj = sum(TCost)/len(TCost)
    AvgCost.append(round(ave_obj,2))
    StdCost.append((sum((TCost[i] - ave_obj)**2 for i in range(len(TCost)))/(N-1))**0.5)
    time = final - start
    Times.append(time.seconds)
    Viols.append(vviol)
    print(tau)
    print('AvgCost:', AvgCost[-1])
    print('StdCost:', StdCost[-1])
    print('Time   :', Times[-1])
    print('Viols? :', Viols[-1])

print('Finished!')
#%%

#df = pd.DataFrame(data=AvgCost)
#df.to_excel('VTPVSSi-July7.xlsx')
'''
plot = plt.figure(1)
plt.plot(range(len(AvgCost)), AvgCost)
plt.xlabel('Scenario')
plt.ylabel('Total discounted costs')'''
#%% Results   
'''
print('Initial state:', now)

ave_obj = sum(TCost)/len(TCost)
print('Average value f for current state:', round(ave_obj,2))
std_obj = (sum((TCost[i] - ave_obj)**2 for i in range(len(TCost)))/(N-1))**0.5
print('STD value f for current state:', round(std_obj,2))
print('min f value:', round(min(TCost),2), '- max f value:', round(max(TCost),2))

time = final - start
print('Run time:', time.seconds)

ave_period = sum(period)/len(period)
print('Average simulation time horizon:', round(ave_period,2))
std_period = (sum((period[i] - ave_period)**2 for i in range(len(period)))/(N-1))**0.5
print('STD simulation time horizon:', round(std_period,2))
#%%
plot = plt.figure(1)
plt.plot(range(len(TCost)), TCost)
plt.xlabel('Scenario')
plt.ylabel('Total discounted costs')'''
#%%
#file = 'Example-2-heu'
#C_list = pd.DataFrame(TCost)
#C_list.to_excel(file+'.xlsx', sheet_name=file)