# -*- coding: utf-8 -*-
"""
Created on Sun Apr 21 17:31:08 2024

@author: amirr
"""
import pandas as pd
import math
import random
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
from pyomo.environ import *

R = RangeSet(4)
T = RangeSet(3)
M = RangeSet(4)

d = {r: 190 for r in R}
b = {m: 90 for m in M}

model = ConcreteModel()

model.y = Var(T, within = Binary)
model.x = Var(T, M, R, within = Binary)

model.OF = Objective(expr = sum(model.y[t] for t in T))

model.limit = ConstraintList()

for r in R:
    model.limit.add(sum(b[m] * model.x[t,m,r] for m in M for t in T) >= d[r])
'''
for t in T:
    for m in M:
        for r in R:
            model.limit.add(model.x[t,m,r] <= model.y[t])'''

for m in M:
    for t in T:
        model.limit.add(sum(model.x[t,m,r] for r in R) <= model.y[t])

for j in RangeSet(2):
    model.limit.add(model.y[j] >= model.y[j+1])

solver = SolverFactory('cplex').solve(model)
display(model.OF)
display(model.y)
display(model.x)