"""
ADP code for CMFLP-MUD
Author : Amirreza Pashapour - 2024
"""
# Libraries
import pandas as pd
import random
import math
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
# genetic algorithm search of the one max optimization problem
# from numpy.random import randint
from numpy.random import rand
#%%
def combination(arr):  # This function is used several times to choose a combination from sets
    y = []
    # number of arrays
    n = len(arr)
    # to keep track of next element in each of the n arrays
    indices = [0 for i in range(n)]
    while (1):
        # prcurrent combination
        a = []
        for i in range(n):
            a.append(arr[i][indices[i]])
        y.append(a)
        # find the rightmost array that has more elements left
        # after the current element in that array
        next = n - 1
        while (next >= 0 and
               (indices[next] + 1 >= len(arr[next]))):
            next -= 1
        # no such array is found so no more combinations left
        if (next < 0):
            return y
        # if found move to next element in that array
        indices[next] += 1
        # for all arrays to the right of this array current index
        # again points to first element
        for i in range(next + 1, n):
            indices[i] = 0

# %% Pij matrix generation
def P_calc(p_state,p_state_dest):
    finalP = 1
    for r in R:
        i = p_state[0][r-1][1]       # l^r_t
        if i in Camp:
            continue
        else:                # en route  # computing scores
            u2 = 0
            if p_state_dest[1][r-1][1] == tau:
                u2 = 1
            
            score = {}
            for j in Rgraph[i]:
                score[(i,j)] = W_vector['w1'] * NDist[(i,j)] + W_vector['w2'] * Popularity[j] + W_vector['w3'] * SPIndex[(i,j)] 
                
            score[(i,i)] = W_vector['w4'] * (tau - p_state[1][r-1][1]) + W_vector['w5'] * (1 - u2) + W_vector['w6'] * (1-Velocity[r]) 
            #print(score)
            finalP *= (score[i,p_state_dest[0][r-1][1]])/(sum(score.values()))
            
    return finalP

# %% Action generation
def A_gen(a_state): 
    dest_a = []
    service_loc = list(set([v for v in [a_state[0][r-1][1] for r in R] if v in Im]))
    for m in M:
        dest_a_m = []
        for y in [0,1]:
            if y == 0: # No action
                dest_a_m.append([m,y,a_state[2][m-1][1]])
            else:
                for idx in service_loc:
                    dest_a_m.append([m,y,idx])
        dest_a.append(dest_a_m)
    good_a = []
    for act in combination(dest_a):
        capacity = {}
        boolean = {}
        demand = {}
        for idx in service_loc:
            capacity[idx] = 0
            boolean[idx] = 0
            for m in M:
                if act[m-1][1]==1 and act[m-1][2]==idx:
                    capacity[idx] += b[m]
                    boolean[idx] = 1
                    
            demand[idx] = 0
            for r in R:
                if a_state[0][r-1][1] == idx:
                    demand[idx] += d[r]
        add = True
        for idx in service_loc:
            if capacity[idx] < demand[idx] * boolean[idx]:
                add = False
                break
        if add == True:
            good_a.append(act)

    return good_a

def POP_GA(a_state, ThetaGA):
    n_pop = 5*(len(R) + len(M))
    c_rate = 0.8
    m_rate = 0.5
    Gen = 2*(len(R) + len(M))
    n_c = math.ceil(c_rate * n_pop)
    #Bests = []
    POP = []
    FIT = []
    
    # POP gen
    service_loc = list(set([v for v in [a_state[0][r-1][1] for r in R] if v in Im]))
    service_loc.sort()

    for i in range(n_pop):
        x = []
        if len(service_loc) == 0:
            x = [[m, 0, a_state[2][m-1][1]] for m in M]
        else:
            for m in M:
                yy = random.randint(0,1)
                if yy == 0:
                    qm = a_state[2][m-1][1]
                else:
                    qm = service_loc[random.randint(0, len(service_loc)-1)]
                x.append([m,yy,qm])
        POP.append(x)

    for i in POP:
        FIT.append(Fitness(a_state,i,ThetaGA,service_loc))
    
    FIT, POP = Sort(FIT, POP)
    #Best_action = POP[0]
    #Bests.append(FIT[0])
    
    for _ in range(Gen):
        
        for _ in range(n_c):
            Par1 = POP[random.randint(0, len(POP)-1)]
            Par2 = POP[random.randint(0, len(POP)-1)]
            
            chi1 , chi2 = Single_crossover(Par1, Par2)
            
            if rand() <= m_rate:
                chi1 = Mutate(chi1,a_state,service_loc)
            if rand() <= m_rate:
                chi2 = Mutate(chi1,a_state,service_loc)
            
            POP.append(chi1)
            FIT.append(Fitness(a_state, chi1, ThetaGA,service_loc))
            POP.append(chi2)
            FIT.append(Fitness(a_state, chi2, ThetaGA,service_loc))
        FIT, POP = Sort(FIT, POP)
        FIT = FIT[0:n_pop]
        POP = POP[0:n_pop]
        #Best_action = POP[0]
        #Bests.append(FIT[0])

    return POP[0], FIT[0]

def Single_crossover(x1,x2):
    b = random.randint(0, len(x1))
    y1 = []
    y2 = []
    
    y1 = x1[:b] + x2[b:]
    y2 = x2[:b] + x1[b:]
    return y1, y2

def Mutate(x, a_state, L_RG):
    if len(L_RG) <= 1:
        return x
    else:
        b = random.randint(1, len(x))
        All = [[b,0,a_state[2][b-1][1]]]
        for l in L_RG:
            All.append([b,1,l])
        All.remove(x[b-1])
        x[b-1] = All[random.randint(0, len(All) - 1)]
    return x

def Sort(list1,list2):
    # Zip the lists together
    paired_lists = list(zip(list1, list2))
    
    # Sort the paired lists based on the first list
    paired_lists.sort()
    
    # Unzip the sorted pairs back into two lists
    sorted_list1, sorted_list2 = zip(*paired_lists)
    
    # Convert tuples back to lists (optional)
    sorted_list1 = list(sorted_list1)
    sorted_list2 = list(sorted_list2)
    
    return sorted_list1, sorted_list2

def Fitness(a_state,sol,thetaa,L_RG):
    
    Z = Cost_Function(a_state, sol)
    
    capacity = {}
    boolean = {}
    demand = {}
    for idx in L_RG:
        capacity[idx] = 0
        boolean[idx] = 0
        for m in M:
            if sol[m-1][1]==1 and sol[m-1][2]==idx:
                capacity[idx] += b[m]
                boolean[idx] = 1
                
        demand[idx] = 0
        for r in R:
            if a_state[0][r-1][1] == idx:
                demand[idx] += d[r]
    for idx in L_RG:
        if capacity[idx] < demand[idx] * boolean[idx]:
            Z+= 1000000
            break
    
    Z += B * Basis(Next_Post_State(a_state, sol), thetaa)
    
    return Z

# %% Cost function
def Cost_Function(a_state, a_action):
    GG = list(set(a_action[m-1][2] for m in M if a_action[m-1][1] == 1))
    #service
    serviceActCost = sum(o * d[r] for r in R if a_state[0][r-1][1] in GG)
    #relocation
    relocationCost = sum(c[(a_state[2][m-1][1],a_action[m-1][2])] for m in M if a_action[m-1][1] == 1)
    #penalty
    penaltyCost = sum(gamma * d[r] for r in R if a_state[1][r-1][1] == 1 and a_state[0][r-1][1] not in GG)
         
    return relocationCost + serviceActCost + penaltyCost

#%% Next States

def Next_Post_State(a_state, a_action):
    U_list = []
    dest = list(set([a_action[m-1][2] for m in M if a_action[m-1][1] == 1]))
    target_r = [r for r in R if a_state[0][r-1][1] in dest]
    for r in R:
        if r in target_r or a_state[0][r-1][1] in Camp:
            U_list.append((r, tau))
        else:
            U_list.append((r, max(1,a_state[1][r-1][1]-1)))
    return ((a_state[0]), tuple(U_list), tuple([(m, a_action[m-1][2]) for m in M]))

#%%
def Roulette_Wheel(Prob):
    C = np.cumsum(Prob)
    rnd = random.random()
    for i in range(len(Prob)):
        if C[i] >= rnd:
            break
    return i    # returning a index

def Next_State(p_state): # Transition from a post-state to next pre-state. Only LR is updated
    # Part 1 - LR
    Adj_list = []
    for r in R:
        r_adj = [p_state[0][r-1][1]]  # append r's current location
        if p_state[0][r-1][1] not in Camp:
            for j in Rgraph[p_state[0][r-1][1]]:
                r_adj.append(j)
        Adj_list.append(r_adj)
    comb_adj_list = combination(Adj_list)
    Next_LR = []
    for i in range(len(comb_adj_list)):
        Next_LR_ind = []
        for r in R:
            Next_LR_ind.append((r, comb_adj_list[i][r-1]))
        Next_LR.append(Next_LR_ind)
    # Part 2 - U
    ULR = []
    for nlr in Next_LR:
        U_list = []
        for r in R:
            if nlr[r-1][1] in Camp:
                U_list.append((r, tau))
            else:
                U_list.append((r, p_state[1][r-1][1]))
        ULR.append((tuple(nlr), tuple(U_list)))

    Next_S = [(ULR[i][0], ULR[i][1], p_state[2]) for i in range(len(Next_LR))]
    P_S = {s:P_calc(p_state, s) for s in Next_S}
    return Next_S, P_S

#%%
def PHI(postS): # returns a vector of features with size R.
    vector = []
    for r in R:
        vector.append((d[r]/tau) * max(0, (len(SP[postS[0][r-1][1]])-1)/Velocity[r] - postS[1][r-1][1] + 1))
    
    LR1 = list(set(postS[0][r-1][1] for r in R if postS[1][r-1][1] == 1))
    bfunc2 = max(0 , -len(M) + sum(math.ceil(sum( d[r] / bbar for r in R if postS[0][r-1][1] == j)) for j in LR1))
    vector.append(bfunc2)
    return vector

def Basis(postSS, Coeff): # returns the basis function evaluation
    phi = PHI(postSS)
    return sum(Coeff[i-1] * phi[i-1] for i in range(len(phi)))

def State_gen():
    sLR= [tuple([r, Ir[random.randint(0, len(Ir)-1)]]) for r in R]
    sU = []
    for r in R:
        if sLR[r-1][1] not in Camp:
            sU.append((r, random.randint(1, tau)))
        else:
            sU.append((r, tau))
    sLM=[tuple([m, Im[random.randint(0, len(Im)-1)]]) for m in M]
    return (tuple(sLR), tuple(sU), tuple(sLM))

def State_gen_LU():
    sLR= [tuple([r, Ir[random.randint(0, len(Ir)-1)]]) for r in R]
    sU = []
    for r in R:
        if sLR[r-1][1] not in Camp:
            sU.append((r, random.randint(1, tau)))
        else:
            sU.append((r, tau))
    
    return (tuple(sLR), tuple(sU))

def State_gen_Q():
    sLM=[tuple([m, Im[random.randint(0, len(Im)-1)]]) for m in M]
    return (tuple(sLM),)

def Xstar(preS, Coefff):
    action_list = A_gen(preS)    # Corresponding actions
    ActionCosts = [Cost_Function(preS, a) + B * Basis(Next_Post_State(preS, a), Coefff) for a in action_list]
    return action_list[ActionCosts.index(min(ActionCosts))]

def Optimize(ss,coef):
    return min([Cost_Function(ss, a) + B * Basis(Next_Post_State(ss, a), coef) for a in A_gen(ss)])
#%%
'''
Instance_List = ['\\I01-R2M2.xlsx', '\\I02-R2M3.xlsx', '\\I03-R3M3.xlsx', '\\I04-R3M4.xlsx', '\\I05-R4M3.xlsx',
                 '\\I06-R4M4.xlsx', '\\I07-R5M5.xlsx', '\\I08-R5M6.xlsx', '\\I09-R6M7.xlsx', '\\I10-R6M8.xlsx',
                 '\\I11-R6M9.xlsx', '\\I12-R7M9.xlsx', '\\I13-R7M10.xlsx', '\\I14-R7M11.xlsx', '\\I15-R8M11.xlsx',
                 '\\I16-R8M12.xlsx', '\\I17-R8M13.xlsx', '\\I18-R9M13.xlsx', '\\I19-R9M14.xlsx', '\\I20-R9M15.xlsx']
Instance_List = ['\\I01-R2M2.xlsx', '\\I02-R2M3.xlsx', '\\I03-R3M3.xlsx', '\\I04-R3M4.xlsx', '\\I05-R4M3.xlsx',
                 '\\I06-R4M4.xlsx', '\\I07-R5M5.xlsx', '\\I08-R5M6.xlsx', '\\I09-R6M7.xlsx', '\\I10-R6M8.xlsx']'''

Instance_List = ['\\I11-R6M9.xlsx', '\\I12-R7M9.xlsx', '\\I13-R7M10.xlsx', '\\I14-R7M11.xlsx', '\\I15-R8M11.xlsx',
'\\I16-R8M12.xlsx', '\\I17-R8M13.xlsx', '\\I18-R9M13.xlsx', '\\I19-R9M14.xlsx', '\\I20-R9M15.xlsx']
Instance_List = ['\\I19-R9M14.xlsx', '\\I20-R9M15.xlsx']
#Instance_List = ['\\I02-R2M3.xlsx']

VNOWS = [] 
VECTORS = []
Times   = []
IsGA = True
for instance_id in Instance_List:
    
    # % Connecting to Excel
    address1 = r'C:\Users\apashapour20\Desktop\New POMS\Cap-MFLP-UMD-Instances\Datasets\Network.xlsx'
    address2 = r'C:\Users\apashapour20\Desktop\New POMS\Cap-MFLP-UMD-Instances\Datasets' + instance_id

    Network_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Network'))
    Arc_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Arcs'))
    R_data = pd.DataFrame(pd.read_excel(address2, sheet_name='Initial R'))
    M_data = pd.DataFrame(pd.read_excel(address2, sheet_name='Initial M'))
    C_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Cij'))
    Dist_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Dist'))
    SP_data = pd.DataFrame(pd.read_excel(address1, sheet_name='SP'))
    W_data = pd.DataFrame(pd.read_excel(address1, sheet_name='W_vector'))
    Scalars_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Scalars'))
    c = {(i,j):C_data.loc[i][j] for i in range((C_data.shape)[0]) for j in range((C_data.shape)[0])}
    Dists = {(i,j):Dist_data.loc[i][j] for i in range((Dist_data.shape)[0]) for j in range((Dist_data.shape)[0])}

    #%%
    #c = {(i,j): (j-i)**(1.5) + 2 for }
    R    = list(range(1, R_data.shape[0] + 1))

    M    = list(range(1, M_data.shape[0] + 1))
    tau  = int(Scalars_data.loc[0]['Tau'])
    b    = {m:M_data['cap'][m-1] for m in M}
    #o    = {m:M_data['o'][m-1] for m in M}
    Nodes = [int(a) for a in list(Network_data['Nodes'])]

    Ir = list(Network_data['Ir'])
    for i in range(len(Ir)-1, 0, -1):
        if pd.isnull(Ir[i]) == True:
            Ir.pop()
        else:
            break
    Ir = [int(a) for a in Ir]

    Popularity = {i: int(Network_data['Popularity'][Ir.index(i)]) for i in Ir}

    Im = list(Network_data['Im'])
    for i in range(len(Im)-1, 0, -1):
        if pd.isnull(Im[i]) == True:
            Im.pop()
        else:
            break
    Im = [int(a) for a in Im]

    Camp = list(Network_data['Camp'])
    for i in range(len(Camp)-1, 0, -1):
        if pd.isnull(Camp[i]) == True:
            Camp.pop()
        else:
            break
    Camp = [int(a) for a in Camp]

    Arc_list = [(Arc_data['i'][k], Arc_data['j'][k]) for k in range(len(Arc_data))]
    # Adjacent nodes
    Rgraph = {n:[e[1] for e in Arc_list if n == e[0]] for n in Ir}

    NDist = {}
    for i in Ir:
        denom = sum(1/Dists[i,j] for j in Rgraph[i])
        for j in Rgraph[i]:
            NDist[i,j] = round((1/Dists[i,j]) / denom , 3)

    W_vector = {W_data['w'][k]: W_data['value'][k] for k in range(len(W_data))}
    SPIndex  = {(Arc_data['i'][k], Arc_data['j'][k]): Arc_data['SPIndex'][k] for k in range(len(Arc_data))}
    d        = {r: list(R_data['pop'])[r-1] for r in R}
    o        = int(Scalars_data['o'][0])
    gamma    = int(Scalars_data['Gamma'][0])
    bbar     = sum(b.values())/len(M)
    now_LR_r = {r: list(R_data['Location'])[r-1] for r in R}
    Velocity = {r: list(R_data['Velocity'])[r-1] for r in R}
    now_U_r  = {r: list(R_data['U'])[r-1] for r in R}
    now_LM_m = {m: list(M_data['Location'])[m-1] for m in M}
    now_LR   = [tuple([r, now_LR_r[r]]) for r in R]
    now_F    = [tuple([r, now_U_r[r]]) for r in R]
    now_LM   = [tuple([m, now_LM_m[m]]) for m in M]
    now      = (tuple(now_LR), tuple(now_F), tuple(now_LM))
    SP = {}
    for i in range(len(SP_data)):
        row = list(SP_data.loc[i][j] for j in SP_data)
        for j in range(len(row)-1, 0, -1):
            if pd.isnull(row[j]) == True:
                row.pop()
            else:
                break
        SP[int(SP_data.loc[i][1])] = [int(a) for a in row]
    
    # Main Loop
    B     = 0.98   # discount factor
    V_now = []
    Outer = 20
    Middle = 1000
    Inner = 2
    miu   = 10
    delta = 0.5
    STOP = False
    #%
    Theta = [0 for r in range(len(R) + 1)]
    start = datetime.now()
    print(instance_id, '| started at:', start)
    for n in range(1,Outer+1):
        #print(n)
        Omegat1A = []
        Omegat2A = []
        CostVA = []
        a_damp = 1 / n ** delta
        for k in range(1,Middle+1):
            
            L_U = State_gen_LU()
            
            for ins in range(1,Inner+1):
                randompost = L_U + State_gen_Q()
                # Append the current Basis value to the matrices O1
                xx = PHI(randompost)
                Omegat1A.append(xx)
            
                # Simulate to the next pre-state
                new_pre_list, new_pre_prob = Next_State(randompost)
                new_pre = new_pre_list[Roulette_Wheel(list(new_pre_prob.values()))]
                #print(new_pre)                
                if IsGA == True:
                    abest, abestcost = POP_GA(new_pre,Theta)
                else:
                    abest = Xstar(new_pre,Theta)
                    
                new_cost = Cost_Function(new_pre, abest)
                CostVA.append(new_cost)            
                # Append the next Basis value to the matrices O2
                yy = PHI(Next_Post_State(new_pre, abest))
                Omegat2A.append(yy)
            
            final = datetime.now()
            time = final - start
            
            if time.seconds > 8000:
                STOP = True
        # Regressing part 1
        O1A = np.array(Omegat1A)
        O2A = np.array(Omegat2A)
        C1A = np.array(CostVA)
        MTA = np.transpose(O1A)
        # LSTD procedure
        T_hat = np.dot(np.linalg.inv(np.add(np.dot(MTA,np.subtract(O1A,B*O2A)), miu * np.identity(len(Theta)))) , np.dot(MTA,C1A))
    
        # Updating the Theta vector
        Theta = list((1-a_damp) * np.array(Theta) + a_damp * T_hat)
        #Theta[-1] = gamma
        # Record the Vbar of now
        abest, abestcost = POP_GA(now,Theta)
        V_now.append(abestcost)
        final = datetime.now()
        time = final - start
        if STOP == True:
            break
    #%%        
    final = datetime.now()
    time = final - start
    VNOWS.append(V_now)
    VECTORS.append(Theta)
    Times.append(time.seconds) 

    #%%
    #print('Instance : ', instance_id)
    print('Iters    : ', n)
    print('Theta    : ', Theta)
    print('Run Time : ', time.seconds)
    print('V[now]   : ', VNOWS[-1][-1])
    print('-------------------------------------')
    #print('Vbar[now]:', V_now[-1])
#%%
#JJJ = [VNOWS[j] for j in range(len(VNOWS))]
#df = pd.DataFrame(data=JJJ)
#df.to_excel('ADP_VNOWS-August')
#%%
'''
df = pd.DataFrame(data=V_now)
#df = (df.T)
df.to_excel('Vnowa100.xlsx')   '''

#%% Results   
#print('------- g = ',inf,'-------')
'''
print('Initial state:', now)
print('Converged V now:', V_now[-1])
#print('Gap:', round(100*((V_now[0]-V_now[-1])/V_now[0]),2) ,'%')
#print('Optimal action for initial state:' , VFA[State.index(now)])
time = final - start
print('Run time:',time.seconds)
ave_period = round(sum(period)/len(period),2)
print('Average simulatin time horizon:', ave_period)
std_period = round((sum((period[i] - ave_period)**2 for i in range(len(period)))/(N-1))**0.5 , 2)
print('STD simulatin time horizon:', std_period)
'''
'''
Nvisited = 0
print('States with service acts:')
for s in range(len(State)):
    if VFA[s] != 0:
        Nvisited+=1
        
        for m in M:
            if VFA[s][m-1][1]!=0:
                print(State[s], '-', VFA[s])
                break

print('Number of visited states:',len(State))
print('Number of SAs:',round(SA/(1000),2))
print('Number of SAviols:',round(SAviol/(1000),2))'''

plot = plt.figure(1)
plt.plot(range(Outer),V_now)
plt.xlabel('Iteration')
plt.ylabel('Value function')
plt.title('Value function of the initial state') 

#%%
#V_list = pd.DataFrame(V_now)
#V_list.to_excel('I3-a100.xlsx', sheet_name='a')'''