"""
ADP code for CMFLP-MUD
Author : Amirreza Pashapour - 2022
"""
# Libraries
import pandas as pd
import random
import math
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
from pyomo.environ import *

# %% Connecting to Excel
address = r'C:\Users\amirr\OneDrive\Desktop\POMS\Cap-MFLP-UMD\Example-20.xlsx'
Network_data = pd.DataFrame(pd.read_excel(address, sheet_name='Network'))
Arc_data = pd.DataFrame(pd.read_excel(address, sheet_name='Arcs'))
R_data = pd.DataFrame(pd.read_excel(address, sheet_name='Initial R'))
M_data = pd.DataFrame(pd.read_excel(address, sheet_name='Initial M'))
C_data = pd.DataFrame(pd.read_excel(address, sheet_name='Cij'))
SP_data = pd.DataFrame(pd.read_excel(address, sheet_name='SP'))
c = {(i,j):(C_data.loc[i][j]) for i in range((C_data.shape)[0]) for j in range((C_data.shape)[0])}
R    = list(range(1, (R_data.shape)[0] + 1))
M    = list(range(1, (M_data.shape)[0] + 1))
tau  = int(R_data.loc[0]['Tau'])
b    = {m:M_data['cap'][m-1] for m in M}
o    = {m:M_data['o'][m-1] for m in M}

Ir       = list(Network_data['Ir'])
for i in range(len(Ir)-1, 0, -1):
    if pd.isnull(Ir[i]) == True:
        Ir.pop()
    else:
        break
Ir       = [int(a) for a in Ir]
Im       = list(Network_data['Im'])
for i in range(len(Im)-1, 0, -1):
    if pd.isnull(Im[i]) == True:
        Im.pop()
    else:
        break
Im       = [int(a) for a in Im]
Camp     = list(Network_data['Camp'])
for i in range(len(Camp)-1, 0, -1):
    if pd.isnull(Camp[i]) == True:
        Camp.pop()
    else:
        break
Camp     = [int(a) for a in Camp]
Irr = list(set(Ir) - set(Camp))
Arc_list = [(Arc_data['i'][k], Arc_data['j'][k]) for k in range(len(Arc_data))]
Kappa    = {(Arc_data['i'][k], Arc_data['j'][k]):Arc_data['Kappa'][k] for k in range(len(Arc_data))}
Zeta     = {r: R_data['Zeta'][r-1] for r in R}
d        = {r: list(R_data['pop'])[r-1] for r in R}   
now_LR_r = {r: list(R_data['Location'])[r-1] for r in R}
now_U_r  = {r: list(R_data['U'])[r-1] for r in R}
now_LM_m = {m: list(M_data['Location'])[m-1] for m in M}
now_LR   = [tuple([r, now_LR_r[r]]) for r in R]
now_F    = [tuple([r, now_U_r[r]]) for r in R]
now_LM   = [tuple([m, now_LM_m[m]]) for m in M]
now      = (tuple(now_LR), tuple(now_F), tuple(now_LM))

#%%
def combination(arr):  # This function is used several times to choose a combination from sets
    y = []
    # number of arrays
    n = len(arr)
    # to keep track of next element in each of the n arrays
    indices = [0 for i in range(n)]
    while (1):
        # prcurrent combination
        a = []
        for i in range(n):
            a.append(arr[i][indices[i]])
        y.append(a)
        # find the rightmost array that has more elements left
        # after the current element in that array
        next = n - 1
        while (next >= 0 and
               (indices[next] + 1 >= len(arr[next]))):
            next -= 1
        # no such array is found so no more combinations left
        if (next < 0):
            return y
        # if found move to next element in that array
        indices[next] += 1
        # for all arrays to the right of this array current index
        # again points to first element
        for i in range(next + 1, n):
            indices[i] = 0

# Adjacent nodes
Rgraph = {n:[e[1] for e in Arc_list if n == e[0]] for n in Ir}

SP = {}
for i in range(len(SP_data)):
    row = list(SP_data.loc[i][j] for j in SP_data)
    for j in range(len(row)-1, 0, -1):
        if pd.isnull(row[j]) == True:
            row.pop()
        else:
            break
    SP[int(SP_data.loc[i][1])] = [int(a) for a in row]
# %% Pij matrix generation

def Sigma(welfare):
    if welfare == 1:
        return 0.6
    elif welfare == 2:
        return 0.7
    else:
        return 0.8

def P_calc(p_state,p_state_dest):
    finalP = 1
    for r in R:
        i = p_state[0][r-1][1]       # l^r_t
        if i in Camp:
            continue
        else:
            j = p_state_dest[0][r-1][1]  # l^r_t+1
            u2 = p_state_dest[1][r-1][1] # welfare level of RG r in t+1
            denom = Zeta[r] * Kappa[i,SP[i][1]] + (1-Zeta[r]) * sum(Kappa[i,k] for k in Rgraph[i] if k != SP[i][1])
    
            if j == SP[i][1]:  # Case 1
                finalP *= ((Zeta[r] * Kappa[i,j])/denom) * Sigma(u2)
            elif j in Rgraph[i]: # Case 2
                finalP *= (((1-Zeta[r]) * Kappa[i,j])/denom) * Sigma(u2)
            elif j == i:
                finalP *= 1 - (((Zeta[r] * Kappa[i,SP[i][1]])/denom) * Sigma(u2)) - sum((((1-Zeta[r]) * Kappa[i,jj])/denom) * Sigma(u2) for jj in Rgraph[i] if jj != SP[i][1])
            else:
                finalP *= 0
    return finalP

# %% Action generation
def A_gen(a_state): 
    dest_a = []
    service_loc = list(set([v for v in [a_state[0][r-1][1] for r in R] if v in Im]))
    for m in M:
        dest_a_m = []
        for y in [0,1]:
            if y == 0: # No action
                dest_a_m.append([m,y,a_state[2][m-1][1]])
            else:
                for idx in service_loc:
                    dest_a_m.append([m,y,idx])
        dest_a.append(dest_a_m)
    good_a = []
    for act in combination(dest_a):
        capacity = {}
        boolean = {}
        demand = {}
        for idx in service_loc:
            capacity[idx] = 0
            boolean[idx] = 0
            for m in M:
                if act[m-1][1]==1 and act[m-1][2]==idx:
                    capacity[idx] += b[m]
                    boolean[idx] = 1
                    
            demand[idx] = 0
            for r in R:
                if a_state[0][r-1][1] == idx:
                    demand[idx] += d[r]
        add = True
        for idx in service_loc:
            if capacity[idx] < demand[idx] * boolean[idx]:
                add = False
                break
        if add == True:
            good_a.append(act)

    return good_a

# %% Cost function

def Cost_Function(a_state, a_action):
    #service
    serviceActCost = sum(o[m] for m in M if a_action[m-1][1] == 1)
    #relocation
    relocationCost = sum(c[(a_state[2][m-1][1],a_action[m-1][2])] for m in M if a_action[m-1][1] == 1)
    #penalty
    penaltyCost = sum(gamma for r in R if a_state[1][r-1][1] == 1 and a_state[0][r-1][1] not in [a_action[m-1][2] for m in M if a_action[m-1][1] == 1])     
    return relocationCost + serviceActCost + penaltyCost

#%% Next States

def Next_Post_State(a_state, a_action):
    U_list = []
    dest = list(set([a_action[m-1][2] for m in M if a_action[m-1][1] == 1]))
    target_r = [r for r in R if a_state[0][r-1][1] in dest]
    for r in R:
        if r in target_r or a_state[0][r-1][1] in Camp:
            U_list.append((r, tau))
        else:
            U_list.append((r, max(1,a_state[1][r-1][1]-1)))
    return ((a_state[0]), tuple(U_list), tuple([(m, a_action[m-1][2]) for m in M]))

#%%
def Roulette_Wheel(Prob):
    C = np.cumsum(Prob)
    rnd = random.random()
    for i in range(len(Prob)):
        if C[i] >= rnd:
            break
    return i    # returning a index

def Next_State(p_state): # Transition from a post-state to next pre-state. Only LR is updated
    # Part 1 - LR
    Adj_list = []
    for r in R:
        r_adj = [p_state[0][r-1][1]]  # append r's current location
        if p_state[0][r-1][1] not in Camp:
            for j in Rgraph[p_state[0][r-1][1]]:
                r_adj.append(j)
        Adj_list.append(r_adj)
    comb_adj_list = combination(Adj_list)
    Next_LR = []
    for i in range(len(comb_adj_list)):
        Next_LR_ind = []
        for r in R:
            Next_LR_ind.append((r, comb_adj_list[i][r-1]))
        Next_LR.append(Next_LR_ind)
    # Part 2 - U
    ULR = []
    for nlr in Next_LR:
        U_list = []
        for r in R:
            if nlr[r-1][1] in Camp:
                U_list.append((r, tau))
            else:
                U_list.append((r, p_state[1][r-1][1]))
        ULR.append((tuple(nlr), tuple(U_list)))

    Next_S = [(ULR[i][0], ULR[i][1], p_state[2]) for i in range(len(Next_LR))]
    P_S = {s:P_calc(p_state, s) for s in Next_S}
    return Next_S, P_S

#%%
def PHI(postS): # returns a vector of features with size R.
    vector = []
    for r in R:
        rl = postS[0][r-1][1] # placement
        vector.append((1/tau)*max(0, len(SP[rl])/Sigma(2) - postS[1][r-1][1]))
    vector.append(Isviol(postS))
    return vector

def Basis(postSS, Coeff): # returns the basis function value
    phi = PHI(postSS)
    return sum(Coeff[i-1] * phi[i-1] for i in range(len(phi)))

def State_gen():
    sLR= [tuple([r, Ir[random.randint(0, len(Ir)-1)]]) for r in R]
    sU = []
    for r in R:
        if sLR[r-1][1] not in Camp:
            sU.append((r, random.randint(1, tau)))
        else:
            sU.append((r, tau))
    sLM=[tuple([m, Im[random.randint(0, len(Im)-1)]]) for m in M]
    return (tuple(sLR), tuple(sU), tuple(sLM))

def Xstar(preS, Coefff):
    action_list = A_gen(preS)    # Corresponding actions
    ActionCosts = [Cost_Function(preS, a) + B * Basis(Next_Post_State(preS, a), Coefff) for a in action_list]
    return action_list[ActionCosts.index(min(ActionCosts))]

def Isviol(ss):
    R1 = [ss[0][r-1][0] for r in R if ss[1][r-1][1] == 1]
    #LR1 = set([ss[0][r-1][1] for r in R if ss[1][r-1][1] == 1])
    if len(R1) < 0.5:
        return 0
    model = ConcreteModel()
    model.x = Var(M,R1,within = Binary)
    model.OF = Objective(expr = sum(model.x[m,r] for m in M for r in R1), sense = maximize)
    model.limit = ConstraintList()
    for r in R1:
        model.limit.add(sum(b[m] * model.x[m,r] for m in M) >= d[r])
    for m in M:
        model.limit.add(sum(model.x[m,r] for r in R1) <= 1)
    results = SolverFactory('cplex').solve(model)
    if results.solver.termination_condition == TerminationCondition.optimal:
        # Model is feasible
        feasibility = 0
    elif results.solver.termination_condition == TerminationCondition.infeasible:
        # Model is infeasible
        feasibility = 1
    else:
        # Solver status is unknown or something else happened
        feasibility = None
    return feasibility

def Optimize(ss,coef):
    return min([Cost_Function(ss, a) + B * Basis(Next_Post_State(ss, a), coef) for a in A_gen(ss)])
#%% Main Loop
B     = 0.98   # discount factor
#gamma= len(M)*(max(o.values())+max(c.values()))   # penalty
gamma = 100
V_now = []
Outer = 10
Inner = 10
miu   = 10
delta = 0.75
#%%
start = datetime.now()
Theta = [20 for i in range(len(R))]
Theta.append(gamma)
for n in range(1,Outer+1):
    Omegat1 = []
    Omegat2 = []
    CostV = []
    a_damp = 1 / n ** delta
    for k in range(1,Inner+1):
        
        # Simulate a random post state
        #apre = State_gen()
        #apreact = A_gen(apre)
        #randompost = Next_Post_State(apre, apreact[random.randint(0, len(apreact)-1)])
        randompost = State_gen()
        # Append the current Basis value to the matrices O1
        Omegat1.append(PHI(randompost))
        
        # Simulate to the next pre-state
        new_pre_list, new_pre_prob = Next_State(randompost)
        new_pre = new_pre_list[Roulette_Wheel(list(new_pre_prob.values()))]
        
        #measure the C value base on the prestate observed and the bestX
        abest = Xstar(new_pre,Theta)
        CostV.append(Cost_Function(new_pre, abest))
        
        # Append the next Basis value to the matrices O2
        Omegat2.append(PHI(Next_Post_State(new_pre, abest)))
        
    # Regressing
    O1 = np.array(Omegat1)
    O2 = np.array(Omegat2)
    C1 = np.array(CostV)
    MT = np.transpose(O1)
    # LSTD procedure
    T_hat = np.dot(np.linalg.inv(np.add(np.dot(MT,np.subtract(O1,B*O2)), miu * np.identity(len(Theta)))) , np.dot(MT,C1))

    # Updating the Theta vector
    Theta = list((1-a_damp) * np.array(Theta) + a_damp * T_hat)
    
    # Record the Vbar of now
    V_now.append(Optimize(now,Theta))
        
final = datetime.now()
time = final - start
#%%
print('Run Time :', time.seconds)
print('Theta    :', Theta)
print('Vbar[now]:', V_now[-1])
#%%
'''
df = pd.DataFrame(data=V_now)
#df = (df.T)
df.to_excel('Vnowa100.xlsx')   ''' 

#%% Results   
#print('------- g = ',inf,'-------')
'''
print('Initial state:', now)
print('Converged V now:', V_now[-1])
#print('Gap:', round(100*((V_now[0]-V_now[-1])/V_now[0]),2) ,'%')
#print('Optimal action for initial state:' , VFA[State.index(now)])
time = final - start
print('Run time:',time.seconds)
ave_period = round(sum(period)/len(period),2)
print('Average simulatin time horizon:', ave_period)
std_period = round((sum((period[i] - ave_period)**2 for i in range(len(period)))/(N-1))**0.5 , 2)
print('STD simulatin time horizon:', std_period)
'''
'''
Nvisited = 0
print('States with service acts:')
for s in range(len(State)):
    if VFA[s] != 0:
        Nvisited+=1
        
        for m in M:
            if VFA[s][m-1][1]!=0:
                print(State[s], '-', VFA[s])
                break'''
'''
print('Number of visited states:',len(State))
print('Number of SAs:',round(SA/(1000),2))
print('Number of SAviols:',round(SAviol/(1000),2))
'''
plot = plt.figure(1)
plt.plot(range(len(V_now)),V_now)
plt.xlabel('Iteration')
plt.ylabel('Value function')
plt.title('Value function of the initial state') 
#%%
#V_list = pd.DataFrame(V_now)
#V_list.to_excel('I3-a100.xlsx', sheet_name='a')