"""
Author : Amirreza Pashapour - 2025
"""
# Libraries
import pandas as pd
import random
import math
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
# genetic algorithm search of the one max optimization problem
# from numpy.random import randint
from numpy.random import rand
import networkx as nx

#%%
def combination(arr):  # This function is used several times to choose a combination from sets
    y = []
    # number of arrays
    n = len(arr)
    # to keep track of next element in each of the n arrays
    indices = [0 for i in range(n)]
    while (1):
        # prcurrent combination
        a = []
        for i in range(n):
            a.append(arr[i][indices[i]])
        y.append(a)
        # find the rightmost array that has more elements left
        # after the current element in that array
        next = n - 1
        while (next >= 0 and
               (indices[next] + 1 >= len(arr[next]))):
            next -= 1
        # no such array is found so no more combinations left
        if (next < 0):
            return y
        # if found move to next element in that array
        indices[next] += 1
        # for all arrays to the right of this array current index
        # again points to first element
        for i in range(next + 1, n):
            indices[i] = 0

# %% Action generation
Action = []   # General list for actions

def A_gen(a_state): 
    dest_a = []
    service_loc = list(set([v for v in [a_state[0][r-1][1] for r in R if a_state[0][r-1][1] in J]]))
    for m in M:
        dest_a_m = []
        for y in [0,1]:
            if y == 0: # No action
                dest_a_m.append([m,y,a_state[2][m-1][1]])
            else:
                for idx in service_loc:
                    dest_a_m.append([m,y,idx])
        dest_a.append(dest_a_m)
    good_a = []
    for act in combination(dest_a):
        capacity = {}
        boolean = {}
        demand = {}
        for idx in service_loc:
            capacity[idx] = 0
            boolean[idx] = 0
            for m in M:
                if act[m-1][1]==1 and act[m-1][2]==idx:
                    capacity[idx] += b[m]
                    boolean[idx] = 1
                    
            demand[idx] = 0
            for r in R:
                if a_state[0][r-1][1] == idx:
                    demand[idx] += d[r]
        add = True
        for idx in service_loc:
            if capacity[idx] < demand[idx] * boolean[idx]:
                add = False
        if add == True:
            good_a.append(act)

    return good_a

def POP_GA(a_state, ThetaGA):
    n_pop  = 5*(len(R) + len(M))
    Gen    = 4*(len(R) + len(M))
    c_rate = 1
    m_rate = 0.2
    n_c = math.ceil(c_rate * n_pop / 2)
    #Bests = []
    POP = []
    FIT = []
    
    # POP gen
    service_loc = list(set([v for v in [a_state[0][r-1][1] for r in R] if v in J]))
    service_loc.sort()

    for i in range(n_pop):
        x = []
        if len(service_loc) == 0:
            x = [[m, 0, a_state[2][m-1][1]] for m in M]
        else:
            for m in M:
                yy = random.randint(0,1)
                if yy == 0:
                    qm = a_state[2][m-1][1]
                else:
                    qm = service_loc[random.randint(0, len(service_loc)-1)]
                x.append([m,yy,qm])
        POP.append(x)

    for i in POP:
        FIT.append(Fitness(a_state,i,ThetaGA,service_loc))
    
    FIT, POP = Sort(FIT, POP)
    
    for _ in range(Gen):
        
        for _ in range(n_c):
            Par1 = POP[random.randint(0, len(POP)-1)]
            Par2 = POP[random.randint(0, len(POP)-1)]
            
            chi1 , chi2 = Single_crossover(Par1, Par2)
            
            if rand() <= m_rate:
                chi1 = Mutate(chi1,a_state,service_loc)
            if rand() <= m_rate:
                chi2 = Mutate(chi1,a_state,service_loc)
            
            POP.append(chi1)
            FIT.append(Fitness(a_state, chi1, ThetaGA,service_loc))
            POP.append(chi2)
            FIT.append(Fitness(a_state, chi2, ThetaGA,service_loc))
        FIT, POP = Sort(FIT, POP)
        FIT = FIT[0:n_pop]
        POP = POP[0:n_pop]

    return POP[0], FIT[0]

def Single_crossover(x1,x2):
    b = random.randint(0, len(x1))
    y1 = []
    y2 = []
    
    y1 = x1[:b] + x2[b:]
    y2 = x2[:b] + x1[b:]
    return y1, y2

def Mutate(x, a_state, L_RG):
    if len(L_RG) <= 1:
        return x
    else:
        b = random.randint(1, len(x))
        All = [[b,0,a_state[2][b-1][1]]]
        for l in L_RG:
            All.append([b,1,l])
        All.remove(x[b-1])
        x[b-1] = All[random.randint(0, len(All) - 1)]
    return x

def Sort(list1,list2):
    # Zip the lists together
    paired_lists = list(zip(list1, list2))
    
    # Sort the paired lists based on the first list
    paired_lists.sort()
    
    # Unzip the sorted pairs back into two lists
    sorted_list1, sorted_list2 = zip(*paired_lists)
    
    # Convert tuples back to lists (optional)
    sorted_list1 = list(sorted_list1)
    sorted_list2 = list(sorted_list2)
    
    return sorted_list1, sorted_list2

def Fitness(a_state,sol,thetaa,L_RG):
    
    Z = Cost_Function(a_state, sol) + B * Basis(Next_Post_State(a_state, sol), thetaa)
    
    capacity = {}
    boolean = {}
    demand = {}
    for idx in L_RG:
        capacity[idx] = 0
        boolean[idx] = 0
        for m in M:
            if sol[m-1][1]==1 and sol[m-1][2]==idx:
                capacity[idx] += b[m]
                boolean[idx] = 1
                
        demand[idx] = 0
        for r in R:
            if a_state[0][r-1][1] == idx:
                demand[idx] += d[r]
    for idx in L_RG:
        if capacity[idx] < demand[idx] * boolean[idx]:
            Z+= 1000000
            break
    return Z

# %% Cost function
def Cost_Function(a_state, a_action):
    GG = list(set(a_action[m-1][2] for m in M if a_action[m-1][1] == 1))
    #service
    serviceActCost = sum(o * d[r] for r in R if a_state[0][r-1][1] in GG)
    #relocation
    relocationCost = sum(c[(a_state[2][m-1][1],a_action[m-1][2])] + c[(a_action[m-1][2],g[a_action[m-1][2]])] for m in M if a_action[m-1][1] == 1)
    #penalty
    penaltyCost = sum(gamma * d[r] for r in R if a_state[1][r-1][1] == 1 and a_state[0][r-1][1] not in GG)
         
    return relocationCost + serviceActCost + penaltyCost

#%% Next States

def Next_Post_State(a_state, a_action):
    U_list = []
    dest = list(set([a_action[m-1][2] for m in M if a_action[m-1][1] == 1]))
    target_r = [r for r in R if a_state[0][r-1][1] in dest]
    for r in R:
        if r in target_r or a_state[0][r-1][1] in Camp:
            U_list.append((r, tau))
        else:
            U_list.append((r, max(1,a_state[1][r-1][1]-1)))
    return ((a_state[0]), tuple(U_list), tuple([(m, g[a_action[m-1][2]]) for m in M]))

#%%
def Roulette_Wheel(Prob):
    C = np.cumsum(Prob)
    rnd = random.random()
    for i in range(len(Prob)):
        if C[i] >= rnd:
            break
    return i    # returning a index

def Next_State(p_state): # Transition from a post-state to next pre-state. Only LR is updated
    # Part 1 - LR
    Adj_list = []
    for r in R:
        r_adj = [p_state[0][r-1][1]]  # append r's current location
        if p_state[0][r-1][1] not in Camp:
            for j in Adjacent[p_state[0][r-1][1]]:
                r_adj.append(j)
        Adj_list.append(r_adj)
    comb_adj_list = combination(Adj_list)
    Next_LR = []
    for i in range(len(comb_adj_list)):
        Next_LR_ind = []
        for r in R:
            Next_LR_ind.append((r, comb_adj_list[i][r-1]))
        Next_LR.append(Next_LR_ind)
    # Part 2 - U
    ULR = []
    for nlr in Next_LR:
        U_list = []
        for r in R:
            if nlr[r-1][1] in Camp:
                U_list.append((r, tau))
            else:
                U_list.append((r, p_state[1][r-1][1]))
        ULR.append((tuple(nlr), tuple(U_list)))

    Next_S = [(ULR[i][0], ULR[i][1], p_state[2]) for i in range(len(Next_LR))]
    P_S = {s:math.prod(P[(p_state[0][r-1][1]),s[0][r-1][1]] for r in R) for s in Next_S}
    return Next_S, P_S

#%%
def PHI(postS): # returns a vector of features with size R.
    vector = []
    for r in R:
        vector.append(max(0, (d[r]/tau) * (Xi[postS[0][r-1][1]]/sigma2bar - postS[1][r-1][1])))
    LR1 = list(set(postS[0][r-1][1] for r in R if postS[1][r-1][1] == 1))
    bfunc2 = max(0 , -len(M) + sum(math.ceil(sum( d[r] / bbar for r in R if postS[0][r-1][1] == j)) for j in LR1))
    vector.append(bfunc2)
    return vector

def Basis(postSS, Coeff): # returns the basis function evaluation
    phi = PHI(postSS)
    return sum(Coeff[i-1] * phi[i-1] for i in range(len(phi)))

def State_gen():
    sLR= [tuple([r, VR[random.randint(0, len(VR)-1)]]) for r in R]
    sU = []
    for r in R:
        if sLR[r-1][1] not in Camp:
            sU.append((r, random.randint(1, tau)))
        else:
            sU.append((r, tau))
    sLM=[tuple([m, Depot[random.randint(0, len(Depot)-1)]]) for m in M]
    return (tuple(sLR), tuple(sU), tuple(sLM))

def State_gen_LU():
    sLR= [tuple([r, VR[random.randint(0, len(VR)-1)]]) for r in R]
    sU = []
    for r in R:
        if sLR[r-1][1] not in Camp:
            sU.append((r, random.randint(1, tau)))
        else:
            sU.append((r, tau))
    
    return (tuple(sLR), tuple(sU))

def State_gen_Q():
    sLM=[tuple([m, Depot[random.randint(0, len(Depot)-1)]]) for m in M]
    return (tuple(sLM),)

def Xstar(preS, Coefff):
    action_list = A_gen(preS)    # Corresponding actions
    ActionCosts = [Cost_Function(preS, a) + B * Basis(Next_Post_State(preS, a), Coefff) for a in action_list]
    return action_list[ActionCosts.index(min(ActionCosts))]

def Optimize(ss,coef):
    return min([Cost_Function(ss, a) + B * Basis(Next_Post_State(ss, a), coef) for a in A_gen(ss)])
#%%
def compute_Xi_values(edges):
    """
    edges: list of tuples (i, j), directed arcs from i -> j
    returns: dict of K values {node: K_i}
    """
    # Create a directed graph
    G = nx.DiGraph()
    G.add_edges_from(edges)
    
    # Initialize K values
    K = {}
    
    # Get reverse topological order (start from leaves)
    for node in reversed(list(nx.topological_sort(G))):
        successors = list(G.successors(node))
        num_outgoing = len(successors)
        
        if num_outgoing == 0:
            # Leaf node, K_j = 0
            K[node] = 0
        else:
            # Compute the sum of K_j for all successors j
            sum_Kj = sum(K[j] for j in successors)
            K[node] = 1 + (sum_Kj / num_outgoing)
    
    return K

#%%

Instance_List = ['\\I01-R2M2.xlsx', '\\I02-R2M3.xlsx', '\\I03-R3M3.xlsx', '\\I04-R3M4.xlsx', '\\I05-R4M3.xlsx',
                 '\\I06-R4M4.xlsx', '\\I07-R4M5.xlsx', '\\I08-R5M5.xlsx', '\\I09-R5M6.xlsx', '\\I10-R5M7.xlsx',
                 '\\I11-R6M7.xlsx', '\\I12-R6M8.xlsx', '\\I13-R6M9.xlsx', '\\I14-R7M9.xlsx', '\\I15-R7M10.xlsx',
                 '\\I16-R7M11.xlsx', '\\I17-R8M11.xlsx', '\\I18-R8M12.xlsx', '\\I19-R8M13.xlsx', '\\I20-R9M13.xlsx',
                 '\\I21-R9M14.xlsx', '\\I22-R9M15.xlsx', '\\I23-R10M16.xlsx', '\\I24-R10M17.xlsx', '\\I25-R10M18.xlsx']

VNOWS = [] 
VECTORS = []
Times   = []
IsGA = True

#%%
address1 = r'C:\Users\apashapour20\Desktop\POMS-Revision1\Instances\Datasets\Network.xlsx'
Network_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Network'))
Arc_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Arcs'))
Dist_data = pd.DataFrame(pd.read_excel(address1, sheet_name='Dist'))
Scalars = pd.DataFrame(pd.read_excel(address1, sheet_name='Scalars'))
W_data = pd.DataFrame(pd.read_excel(address1, sheet_name='W_vector'))
#Dists = {(i,j):Dist_data.loc[i][j] for i in range((Dist_data.shape)[0]) for j in range((Dist_data.shape)[0])}
Dists = {}
Nodes= {Network_data['Name'][a-1]: int(a) for a in list(Network_data['Nodes'])}
for row in range(len(Dist_data['Distance'])):
    Dists[(Nodes[Dist_data['City1'][row]],Nodes[Dist_data['City2'][row]])] = Dist_data['Distance'][row]
    Dists[(Nodes[Dist_data['City2'][row]],Nodes[Dist_data['City1'][row]])] = Dist_data['Distance'][row]

for row in range(1,len(Nodes)+1):
    Dists[(row,row)] = 0

c = {idd: Dists[idd]*0.15 for idd in Dists}

#%%
J = list(Network_data['J'])
for i in range(len(J)-1, 0, -1):
    if pd.isnull(J[i]) == True:
        J.pop()
    else:
        break
J = [int(a) for a in J]

Camp = list(Network_data['Camp'])
for i in range(len(Camp)-1, 0, -1):
    if pd.isnull(Camp[i]) == True:
        Camp.pop()
    else:
        break
Camp = [int(a) for a in Camp]

Depot = list(Network_data['Depot'])
for i in range(len(Depot)-1, 0, -1):
    if pd.isnull(Depot[i]) == True:
        Depot.pop()
    else:
        break
Depot = [int(a) for a in Depot]

VR = list(set(J) | set(Camp))
VM = list(set(J) | set(Depot))

Arc_list = [(Arc_data['i'][k], Arc_data['j'][k]) for k in range(len(Arc_data))]
# Adjacent nodes
Adjacent = {n:[e[1] for e in Arc_list if n == e[0]] for n in J}
maxDist = max(Dists.values())
minDist = min({x for x in list(Dists.values()) if x != 0})
zeta    = Scalars['zeta'][0]
gamma    = int(Scalars['gamma'][0])
gamma    = 50
Safety   = {i: Network_data['Safety'][i-1] for i in J}
Openness = {Arc_list[a]: Arc_data['Openness'][a] for a in range(len(Arc_data))}
o        = int(Scalars['o'][0])
tau  = int(Scalars.loc[0]['Tau'])
g = {}
for i in J:
    g[i] = Depot[0]
    for dep in Depot:
        if Dists[(i,dep)] < Dists[(i,g[i])]:
            g[i] = dep
W_vector = {W_data['w'][k]: W_data['value'][k] for k in range(len(W_data))}
Xi = compute_Xi_values(Arc_list)

# %% Pij matrix generation
Arc_dist = {a: Dists[a] for a in Arc_list}
minArcDist = min(Arc_dist.values())
maxArcDist = max(Arc_dist.values())
Proximity  = {a: (maxArcDist - Dists[a])/(maxArcDist - minArcDist) for a in Arc_list}
sigma = {}
sigmaBar = {}
P     = {}
for i in J:
    for j in Adjacent[i]:
        sigma[(i,j)] = W_vector['w1'] * Safety[i] + W_vector['w2'] * Openness[i,j] + W_vector['w3'] * Proximity[(i,j)] + W_vector['w4'] * np.random.randn()     
    sigmaBar[i] = sum(sigma[(i,j)] for j in Adjacent[i])/len(Adjacent[i])
    
for i in J:
    P[(i,i)] = 1/(1 + math.exp(zeta * (sigmaBar[i] - 0.5)))
    for j in Adjacent[i]:
        P[(i,j)] = (1 - 1/(1 + math.exp(zeta * (sigmaBar[i] - 0.5)))) * (math.exp(sigma[(i,j)])/(sum(math.exp(sigma[(i,k)]) for k in Adjacent[i])))
for i in Camp:
    P[(i,i)] = 1

sigma2bar = round(sum(sigma.values())/len(Arc_list),3)
#%%
for instance_id in Instance_List:
    
    # % Connecting to Excel
    address2 = r'C:\Users\apashapour20\Desktop\POMS-Revision1\Instances\Datasets' + instance_id

    R_data = pd.DataFrame(pd.read_excel(address2, sheet_name='Initial R'))
    M_data = pd.DataFrame(pd.read_excel(address2, sheet_name='Initial M'))
    R    = list(range(1, R_data.shape[0] + 1))
    M    = list(range(1, M_data.shape[0] + 1))
    b    = {m:M_data['cap'][m-1] for m in M}
    d        = {r: list(R_data['pop'])[r-1] for r in R}
    bbar = sum(b.values())/len(b)
    now_LR_r = {r: list(R_data['Location'])[r-1] for r in R}
    now_U_r  = {r: list(R_data['U'])[r-1] for r in R}
    now_LM_m = {m: list(M_data['Location'])[m-1] for m in M}
    now_LR   = [tuple([r, now_LR_r[r]]) for r in R]
    now_F    = [tuple([r, now_U_r[r]]) for r in R]
    now_LM   = [tuple([m, now_LM_m[m]]) for m in M]
    now      = (tuple(now_LR), tuple(now_F), tuple(now_LM))
    
    # Main Loop
    B     = 0.99   # discount factor
    V_now = []
    Outer = 10
    Middle = 2500
    Inner = 2
    miu   = 10
    delta = 0.5
    Theta = [1 for r in range(len(R) + 1)]
    start = datetime.now()
    print(instance_id, '| started at:', start)
    for n in range(1,Outer+1):
        #print(n)
        Omegat1A = []
        Omegat2A = []
        CostVA = []
        a_damp = 1 / n ** delta
        for k in range(1,Middle+1):
            
            L_U = State_gen_LU()
            
            for ins in range(1,Inner+1):
                randompost = L_U + State_gen_Q()
                # Append the current Basis value to the matrices O1
                xx = PHI(randompost)
                Omegat1A.append(xx)
            
                # Simulate to the next pre-state
                new_pre_list, new_pre_prob = Next_State(randompost)
                new_pre = new_pre_list[Roulette_Wheel(list(new_pre_prob.values()))]
                #print(new_pre)                
                if IsGA == True:
                    abest, abestcost = POP_GA(new_pre,Theta)
                else:
                    abest = Xstar(new_pre,Theta)
                    
                new_cost = Cost_Function(new_pre, abest)
                CostVA.append(new_cost)            
                # Append the next Basis value to the matrices O2
                yy = PHI(Next_Post_State(new_pre, abest))
                Omegat2A.append(yy)
            
            final = datetime.now()
            time = final - start

        # Regressing part 1
        O1A = np.array(Omegat1A)
        O2A = np.array(Omegat2A)
        C1A = np.array(CostVA)
        MTA = np.transpose(O1A)
        # LSTD procedure
        T_hat = np.dot(np.linalg.inv(np.add(np.dot(MTA,np.subtract(O1A,B*O2A)), miu * np.identity(len(Theta)))) , np.dot(MTA,C1A))
    
        # Updating the Theta vector
        Theta = list((1-a_damp) * np.array(Theta) + a_damp * T_hat)

        # Record the Vbar of now
        abest, abestcost = POP_GA(now,Theta)
        V_now.append(abestcost)
        final = datetime.now()
        time = final - start

    #%%        
    final = datetime.now()
    time = final - start
    VNOWS.append(V_now)
    VECTORS.append(Theta)
    Times.append(time.seconds) 

    #%%
    #print('Instance : ', instance_id)
    print('Iters completed: ', n)
    print('Theta          : ', Theta)
    print('Run Time       : ', time.seconds)
    print('V[now]         : ', VNOWS[-1][-1])
    print('V[instance]    : ')
    print(VNOWS[-1])
    print('-------------------------------------')