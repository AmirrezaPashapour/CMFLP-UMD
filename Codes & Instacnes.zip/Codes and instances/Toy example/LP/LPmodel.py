"""
Author : Amirreza Pashapour - 2025
"""
# Libraries
import pandas as pd
import numpy as np
import math
import random
from datetime import datetime
import matplotlib.pyplot as plt
from pyomo.environ import *

## %% Connecting to Excel
address = r'C:\Users\apashapour20\Desktop\POMS-Revision1\CMFLP-UMD-Toy\Toy example.xlsx'
Network_data = pd.DataFrame(pd.read_excel(address, sheet_name='Network'))
Arc_data = pd.DataFrame(pd.read_excel(address, sheet_name='Arcs'))
R_data = pd.DataFrame(pd.read_excel(address, sheet_name='Initial R'))
M_data = pd.DataFrame(pd.read_excel(address, sheet_name='Initial M'))
C_data = pd.DataFrame(pd.read_excel(address, sheet_name='Cij'))
Dist_data = pd.DataFrame(pd.read_excel(address, sheet_name='Dist'))
W_data = pd.DataFrame(pd.read_excel(address, sheet_name='W_vector'))
c = {(i+1,j):C_data.loc[i][j] for i in range((C_data.shape)[0]) for j in range(1,(C_data.shape)[0]+1)}
Dists = {(i+1,j):Dist_data.loc[i][j] for i in range((Dist_data.shape)[0]) for j in range(1,(Dist_data.shape)[0]+1)}
#%%
R    = list(range(1, R_data.shape[0] + 1))
M    = list(range(1, M_data.shape[0] + 1))
tau  = int(R_data.loc[0]['Tau'])
b    = {m:M_data['cap'][m-1] for m in M}
Nodes= [int(a) for a in list(Network_data['Nodes'])]

J = list(Network_data['J'])
for i in range(len(J)-1, 0, -1):
    if pd.isnull(J[i]) == True:
        J.pop()
    else:
        break
J = [int(a) for a in J]

Camp = list(Network_data['Camp'])
for i in range(len(Camp)-1, 0, -1):
    if pd.isnull(Camp[i]) == True:
        Camp.pop()
    else:
        break
Camp = [int(a) for a in Camp]

Depot = list(Network_data['Depot'])
for i in range(len(Depot)-1, 0, -1):
    if pd.isnull(Depot[i]) == True:
        Depot.pop()
    else:
        break
Depot = [int(a) for a in Depot]

VR = list(set(J) | set(Camp))
VM = list(set(J) | set(Depot))

Arc_list = [(Arc_data['i'][k], Arc_data['j'][k]) for k in range(len(Arc_data))]
# Adjacent nodes
Adjacent = {n:[e[1] for e in Arc_list if n == e[0]] for n in J}
maxDist = max(Dists.values())
minDist = min({x for x in list(Dists.values()) if x != 0})
zeta = R_data['zeta'][0]
#%%
g = {}
for i in J:
    g[i] = Depot[0]
    for dep in Depot:
        if Dists[(i,dep)] < Dists[(i,g[i])]:
            g[i] = dep
W_vector = {W_data['w'][k]: W_data['value'][k] for k in range(len(W_data))}
d        = {r: list(R_data['pop'])[r-1] for r in R}
o        = int(R_data['o'][0])
gamma    = int(R_data['gamma'][0])
Safety   = {i: Network_data['Safety'][i-1] for i in J}
Openness = {Arc_list[a]: Arc_data['Openness'][a] for a in range(len(Arc_data))}
now_LR_r = {r: list(R_data['Location'])[r-1] for r in R}
now_U_r  = {r: list(R_data['U'])[r-1] for r in R}
now_LM_m = {m: list(M_data['Location'])[m-1] for m in M}
now_LR   = [tuple([r, now_LR_r[r]]) for r in R]
now_F    = [tuple([r, now_U_r[r]]) for r in R]
now_LM   = [tuple([m, now_LM_m[m]]) for m in M]
now      = (tuple(now_LR), tuple(now_F), tuple(now_LM))
#%%
def combination(arr):  # This function is used several times to choose a combination from sets
    y = []
    # number of arrays
    n = len(arr)
    # to keep track of next element in each of the n arrays
    indices = [0 for i in range(n)]

    while (1):
        # prcurrent combination
        a = []
        for i in range(n):
            a.append(arr[i][indices[i]])
        y.append(a)
        # find the rightmost array that has more elements left
        # after the current element in that array
        next = n - 1
        while (next >= 0 and
               (indices[next] + 1 >= len(arr[next]))):
            next -= 1
        # no such array is found so no more combinations left
        if (next < 0):
            return y
        # if found move to next element in that array
        indices[next] += 1
        # for all arrays to the right of this array current index
        # again points to first element
        for i in range(next + 1, n):
            indices[i] = 0

# %% Pij matrix generation
Arc_dist = {a: Dists[a] for a in Arc_list}
minArcDist = min(Arc_dist.values())
maxArcDist = max(Arc_dist.values())
Proximity  = {a: (maxArcDist - Dists[a])/(maxArcDist - minArcDist) for a in Arc_list}
#%%
sigma = {}
sigmaBar = {}
P     = {}
for i in J:
    for j in Adjacent[i]:
        sigma[(i,j)] = W_vector['w1'] * Safety[i] + W_vector['w2'] * Openness[i,j] + W_vector['w3'] * Proximity[(i,j)] + W_vector['w4'] * np.random.randn()     
    sigmaBar[i] = sum(sigma[(i,j)] for j in Adjacent[i])/len(Adjacent[i])
    
for i in J:
    P[(i,i)] = 1/(1 + math.exp(zeta * (sigmaBar[i] - 0.5)))
    for j in Adjacent[i]:
        P[(i,j)] = (1 - 1/(1 + math.exp(zeta * (sigmaBar[i] - 0.5)))) * (math.exp(sigma[(i,j)])/(sum(math.exp(sigma[(i,k)]) for k in Adjacent[i])))
for i in Camp:
    P[(i,i)] = 1
# %% LR & LM generation
LR = [tuple([(r, i[r-1]) for r in R]) for i in combination([VR] * R_data.shape[0])]
U  = [tuple([(r, i[r-1]) for r in R]) for i in combination([list(range(1, tau+1)) for r in R])]
LM = [tuple([(m, i[m-1]) for m in M]) for i in combination([Depot] * M_data.shape[0])]
Removal = []
State = [(lr, u, lm) for lr in LR for u in U for lm in LM]
for s in State:
    for r in R:
        if s[0][r-1][1] in Camp and s[1][r-1][1] != tau:
            Removal.append(s)
State = list(set(State) - set(Removal))

# %% Action generation
Action = []   # General list for actions

def A_gen(a_state): 
    dest_a = []
    service_loc = list(set([v for v in [a_state[0][r-1][1] for r in R if a_state[0][r-1][1] in J]]))
    for m in M:
        dest_a_m = []
        for y in [0,1]:
            if y == 0: # No action
                dest_a_m.append([m,y,a_state[2][m-1][1]])
            else:
                for idx in service_loc:
                    dest_a_m.append([m,y,idx])
        dest_a.append(dest_a_m)
    good_a = []
    for act in combination(dest_a):
        capacity = {}
        boolean = {}
        demand = {}
        for idx in service_loc:
            capacity[idx] = 0
            boolean[idx] = 0
            for m in M:
                if act[m-1][1]==1 and act[m-1][2]==idx:
                    capacity[idx] += b[m]
                    boolean[idx] = 1
                    
            demand[idx] = 0
            for r in R:
                if a_state[0][r-1][1] == idx:
                    demand[idx] += d[r]
        add = True
        for idx in service_loc:
            if capacity[idx] < demand[idx] * boolean[idx]:
                add = False
        if add == True:
            good_a.append(act)

    return good_a

# %% Cost function
def Cost_Function(a_state, a_action):
    GG = list(set(a_action[m-1][2] for m in M if a_action[m-1][1] == 1))
    #service
    serviceActCost = sum(o * d[r] for r in R if a_state[0][r-1][1] in GG)
    #relocation
    relocationCost = sum(c[(a_state[2][m-1][1],a_action[m-1][2])] + c[(a_action[m-1][2],g[a_action[m-1][2]])] for m in M if a_action[m-1][1] == 1)
    #penalty
    penaltyCost = sum(gamma * d[r] for r in R if a_state[1][r-1][1] == 1 and a_state[0][r-1][1] not in GG)
         
    return relocationCost + serviceActCost + penaltyCost

# %% Next States
def Roulette_Wheel(Prob):
    C = np.cumsum(Prob)
    rnd = random.random()
    for i in range(len(Prob)):
        if C[i] >= rnd:
            break
    return i    # returning a index

def Next_State(a_state, a_action):
    # Part 1 - LR
    Adj_list = []
    for r in R:
        r_adj = [a_state[0][r-1][1]]  # append r's current location
        if a_state[0][r-1][1] not in Camp:
            for j in Adjacent[a_state[0][r-1][1]]:
                r_adj.append(j)
        Adj_list.append(r_adj)
    comb_adj_list = combination(Adj_list)
    Next_LR = []
    for i in range(len(comb_adj_list)):
        Next_LR_ind = []
        for r in R:
            Next_LR_ind.append((r, comb_adj_list[i][r-1]))
        Next_LR.append(Next_LR_ind)

    # Part 2 - U
    ULR = []
    target_r = [r for r in R if a_state[0][r-1][1] in list(set([a_action[m-1][2] for m in M if a_action[m-1][1] == 1]))]
    for nlr in Next_LR:
        U_list = []
        for r in R:
            if r in target_r or nlr[r-1][1] in Camp:
                U_list.append((r, tau))
            else:
                U_list.append((r, max(1,a_state[1][r-1][1]-1)))
        ULR.append((tuple(nlr), tuple(U_list)))
    # Part 3 - LM
    M_list = [(m, g[a_action[m-1][2]]) for m in M]
    
    Next_S = [(ULR[i][0], ULR[i][1], tuple(M_list)) for i in range(len(Next_LR))]
    P_S = {s:math.prod(P[(a_state[0][r-1][1]),s[0][r-1][1]] for r in R) for s in Next_S}

    return Next_S, P_S

#%% LP model
B     = 0.99   # discount factor
start = datetime.now()

model = ConcreteModel()
model.V = Var(State, within = NonNegativeReals)
#model.OF = Objective(expr = sum(model.V[s] for s in State) ,sense = maximize)
model.OF = Objective(expr = (1/len(State)) * sum(model.V[s] for s in State) ,sense = maximize)

model.limit = ConstraintList()

for s in State:
    X = A_gen(s)
    for x in X:
        NextStates, Probabilities = Next_State(s, x)
        
        model.limit.add(model.V[s] <= Cost_Function(s, x) + B * sum(Probabilities[ns] * model.V[ns] for ns in NextStates))

#%%
solver = SolverFactory('gurobi').solve(model, tee=False)
end = datetime.now()
print("V*[now] =", value(model.V[now]))